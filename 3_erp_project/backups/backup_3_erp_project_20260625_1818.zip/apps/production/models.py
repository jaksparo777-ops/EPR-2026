from django.db import models
from django.utils import timezone
from apps.master_data.models import LegalEntity, Item, Warehouse, Client
from apps.authentication.models import Worker, JobWorker, ProcessType


class TransactionType(models.TextChoices):
    CASTING_ENTRY = "casting_entry", "Casting Entry"
    MACHINING_OUT = "machining_out", "Machining Issue"
    MACHINING_IN = "machining_in", "Machining Receive"
    POLISHING_OUT = "polishing_out", "Polishing Issue"
    POLISHING_IN = "polishing_in", "Polishing Receive"
    PACKAGING_IN = "packaging_in", "Packaging Receive"
    DISPATCH_OUT = "dispatch_out", "Dispatch Out"
    KITTING_CONSUME = "kitting_consume", "Assembly Consume"
    KITTING_PRODUCE = "kitting_produce", "Assembly Produce"
    STOCK_ADJUSTMENT = "stock_adjustment", "Stock Adjustment"


class StockTransaction(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=50, choices=TransactionType.choices)
    from_warehouse = models.ForeignKey(
        Warehouse, on_delete=models.SET_NULL, related_name='from_transactions', blank=True, null=True
    )
    to_warehouse = models.ForeignKey(
        Warehouse, on_delete=models.SET_NULL, related_name='to_transactions', blank=True, null=True
    )
    worker = models.ForeignKey(Worker, on_delete=models.SET_NULL, blank=True, null=True)
    job_worker = models.ForeignKey(JobWorker, on_delete=models.SET_NULL, blank=True, null=True)
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, blank=True, null=True)
    heat_no = models.CharField(max_length=50, blank=True, null=True)
    quantity = models.IntegerField(default=0)
    rejection_quantity = models.IntegerField(default=0)
    weight = models.FloatField(default=0.0)
    lot_quantity = models.IntegerField(default=0)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.item.code} - {self.get_transaction_type_display()}"


class ItemWorkerAllocation(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='worker_allocations')
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='item_allocations', null=True, blank=True)
    job_worker = models.ForeignKey(JobWorker, on_delete=models.CASCADE, related_name='external_item_allocations', null=True, blank=True)
    rate_per_piece = models.FloatField(default=0.0)

    class Meta:
        verbose_name = "Item Worker Rate"
        verbose_name_plural = "Item Worker Rates"

    def __str__(self):
        worker_name = self.worker.name if self.worker else (self.job_worker.name if self.job_worker else "Unknown")
        return f"{self.item.name} - {worker_name} @ ₹{self.rate_per_piece}"


class AttendanceStatus(models.TextChoices):
    PRESENT = "PRESENT", "Present"
    ABSENT = "ABSENT", "Absent"
    HALF_DAY = "HALF_DAY", "Half Day"


class Attendance(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='attendance_records')
    date = models.DateField(default=timezone.now)
    status = models.CharField(max_length=20, choices=AttendanceStatus.choices, default=AttendanceStatus.PRESENT)
    overtime_hours = models.FloatField(default=0.0)
    notes = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = ('worker', 'date')
        verbose_name_plural = "Attendance Logs"


class Loan(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='loans', null=True, blank=True)
    job_worker = models.ForeignKey(JobWorker, on_delete=models.CASCADE, related_name='loans', null=True, blank=True)
    total_amount = models.FloatField()
    emi_amount = models.FloatField(help_text="Standard monthly deduction")
    remaining_balance = models.FloatField()
    issued_date = models.DateField(default=timezone.now)
    is_active = models.BooleanField(default=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        name = self.worker.name if self.worker else self.job_worker.name
        return f"Loan for {name} (Remaining: ₹{self.remaining_balance})"


class PaymentType(models.TextChoices):
    SALARY = "SALARY", "Salary"
    ADVANCE = "ADVANCE", "Advance"
    NEW_LOAN = "NEW_LOAN", "New Loan"
    JOB_WORK = "JOB_WORK", "Job Work Payment"
    LOAN_REPAYMENT = "LOAN_REPAYMENT", "Loan Repayment"


class LaborPayment(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.SET_NULL, null=True, blank=True)
    job_worker = models.ForeignKey(JobWorker, on_delete=models.SET_NULL, null=True, blank=True)
    amount = models.FloatField()
    date = models.DateField(default=timezone.now)
    payment_type = models.CharField(max_length=20, choices=PaymentType.choices)
    payment_mode = models.CharField(max_length=50, default="CASH")
    reference_no = models.CharField(max_length=100, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)


class Carton(models.Model):
    class CartonStatus(models.TextChoices):
        READY = "READY", "In Warehouse"
        DISPATCHED = "DISPATCHED", "Dispatched"

    class CartonType(models.TextChoices):
        SINGLE = "SINGLE", "Single Item"
        SET = "SET", "Set Item"
        MIXED = "MIXED", "Mixed Carton"

    carton_number = models.CharField(max_length=50, unique=True, blank=True)
    carton_type = models.CharField(max_length=20, choices=CartonType.choices, default=CartonType.SINGLE)
    carton_label = models.CharField(max_length=200, blank=True, null=True)
    
    cleaning = models.BooleanField(default=False)
    labeling = models.BooleanField(default=False)
    packing = models.BooleanField(default=False)
    
    total_quantity = models.IntegerField(default=0)
    total_weight = models.FloatField(default=0.0)
    
    status = models.CharField(max_length=20, choices=CartonStatus.choices, default=CartonStatus.READY)
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, null=True, blank=True, related_name='cartons')
    dispatched_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.carton_number or not str(self.carton_number).strip():
            if self.id:
                self.carton_number = f"CTN-{10000 + self.id}"
            else:
                last_c = Carton.objects.order_by("-id").first()
                base_id = (last_c.id + 1) if last_c else 1
                while True:
                    code = f"CTN-{10000 + base_id}"
                    if not Carton.objects.filter(carton_number=code).exists():
                        self.carton_number = code
                        break
                    base_id += 1
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.carton_number} ({self.get_carton_type_display()}) - {self.get_status_display()}"


class CartonItem(models.Model):
    carton = models.ForeignKey(Carton, on_delete=models.CASCADE, related_name='items')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='carton_contents')
    quantity = models.IntegerField(default=0)
    weight = models.FloatField(default=0.0)

    def __str__(self):
        return f"{self.item.code} x {self.quantity} in {self.carton.carton_number}"
