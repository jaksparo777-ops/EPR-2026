from django.db.models import Sum, Q
from .models import StockTransaction, TransactionType

def get_stock_by_item(item):
    """
    Returns a dictionary of stock quantities for a given item at each stage.
    """
    # Optimized: Use a single query to get all transaction sums for this item, grouped by type, from_warehouse, and to_warehouse
    stats = StockTransaction.objects.filter(item=item).values('transaction_type', 'from_warehouse__code', 'to_warehouse__code').annotate(total=Sum('quantity'))
    
    totals = {}
    adjustments = {
        'CASTING': 0,
        'MACHINING': 0,
        'POLISHING': 0,
        'READY': 0
    }
    
    for s in stats:
        tx_type = s['transaction_type']
        from_wh = s['from_warehouse__code']
        to_wh = s['to_warehouse__code']
        qty = s['total'] or 0
        
        if tx_type == TransactionType.STOCK_ADJUSTMENT:
            if from_wh in adjustments:
                adjustments[from_wh] -= qty
            if to_wh in adjustments:
                adjustments[to_wh] += qty
        elif tx_type == TransactionType.KITTING_CONSUME:
            key = f"{tx_type}_{from_wh}"
            totals[key] = totals.get(key, 0) + qty
        else:
            totals[tx_type] = totals.get(tx_type, 0) + qty
            
    casting_in = totals.get(TransactionType.CASTING_ENTRY, 0)
    machining_out = totals.get(TransactionType.MACHINING_OUT, 0)
    machining_in = totals.get(TransactionType.MACHINING_IN, 0)
    polishing_out = totals.get(TransactionType.POLISHING_OUT, 0)
    polishing_in = totals.get(TransactionType.POLISHING_IN, 0)
    
    # Exclude [DEDICATED BUFFER] transactions from packaging calculations
    dedicated_buffer_qty = StockTransaction.objects.filter(
        item=item,
        transaction_type=TransactionType.PACKAGING_IN,
        notes__contains='[DEDICATED BUFFER]'
    ).aggregate(total=Sum('quantity'))['total'] or 0
    
    packaging_in = max(0, totals.get(TransactionType.PACKAGING_IN, 0) - dedicated_buffer_qty)
    dispatch_out = totals.get(TransactionType.DISPATCH_OUT, 0)
    
    # Bifurcated component consumption
    kitting_consume_machining = totals.get(f"{TransactionType.KITTING_CONSUME}_MACHINING", 0)
    kitting_consume_polishing = totals.get(f"{TransactionType.KITTING_CONSUME}_POLISHING", 0)
    kitting_consume_none = totals.get(f"{TransactionType.KITTING_CONSUME}_None", 0) # Fallback
    
    kitting_produce = totals.get(TransactionType.KITTING_PRODUCE, 0)
    
    return {
        'casting': (casting_in - machining_out) + adjustments['CASTING'],
        'machining': (machining_in - (polishing_out + kitting_consume_machining)) + adjustments['MACHINING'],
        'polishing': (polishing_in - packaging_in) + adjustments['POLISHING'],
        'ready': ((packaging_in + kitting_produce) - dispatch_out) + adjustments['READY']
    }

def get_overall_stock(company=None):
    """
    Returns total stock across all items for each stage. Optionally scoped by company.
    """
    tx_qs = StockTransaction.objects.all()
    buffer_qs = StockTransaction.objects.filter(
        transaction_type=TransactionType.PACKAGING_IN,
        notes__contains='[DEDICATED BUFFER]'
    )
    
    if company:
        if company.id == 2:
            tx_qs = tx_qs.filter(Q(item__company=company) | Q(item__client__name='OM'))
            buffer_qs = buffer_qs.filter(Q(item__company=company) | Q(item__client__name='OM'))
        else:
            tx_qs = tx_qs.filter(item__company=company)
            buffer_qs = buffer_qs.filter(item__company=company)

    stats = tx_qs.values('transaction_type', 'from_warehouse__code', 'to_warehouse__code').annotate(
        total_qty=Sum('quantity'), 
        total_weight=Sum('weight')
    )
    
    qty_totals = {}
    weight_totals = {}
    
    adjustments_qty = {
        'CASTING': 0,
        'MACHINING': 0,
        'POLISHING': 0,
        'READY': 0
    }
    adjustments_wt = {
        'CASTING': 0.0,
        'MACHINING': 0.0,
        'POLISHING': 0.0,
        'READY': 0.0
    }
    
    for s in stats:
        tx_type = s['transaction_type']
        from_wh = s['from_warehouse__code']
        to_wh = s['to_warehouse__code']
        qty = s['total_qty'] or 0
        wt = s['total_weight'] or 0
        
        if tx_type == TransactionType.STOCK_ADJUSTMENT:
            if from_wh in adjustments_qty:
                adjustments_qty[from_wh] -= qty
                adjustments_wt[from_wh] -= wt
            if to_wh in adjustments_qty:
                adjustments_qty[to_wh] += qty
                adjustments_wt[to_wh] += wt
        elif tx_type == TransactionType.KITTING_CONSUME:
            key = f"{tx_type}_{from_wh}"
            qty_totals[key] = qty_totals.get(key, 0) + qty
            weight_totals[key] = weight_totals.get(key, 0) + wt
        else:
            qty_totals[tx_type] = qty_totals.get(tx_type, 0) + qty
            weight_totals[tx_type] = weight_totals.get(tx_type, 0) + wt
            
    # Exclude [DEDICATED BUFFER] packaging transactions from the global totals
    buffer_totals = buffer_qs.aggregate(total_qty=Sum('quantity'), total_weight=Sum('weight'))
    
    dedicated_buffer_qty = buffer_totals['total_qty'] or 0
    dedicated_buffer_weight = buffer_totals['total_weight'] or 0

    casting_qty = (qty_totals.get(TransactionType.CASTING_ENTRY, 0) - qty_totals.get(TransactionType.MACHINING_OUT, 0)) + adjustments_qty['CASTING']
    
    machining_qty = (qty_totals.get(TransactionType.MACHINING_IN, 0) - (
        qty_totals.get(TransactionType.POLISHING_OUT, 0) + 
        qty_totals.get(f"{TransactionType.KITTING_CONSUME}_MACHINING", 0)
    )) + adjustments_qty['MACHINING']
    
    raw_packaging_qty = qty_totals.get(TransactionType.PACKAGING_IN, 0)
    packaging_qty = max(0, raw_packaging_qty - dedicated_buffer_qty)
    
    polishing_qty = (qty_totals.get(TransactionType.POLISHING_IN, 0) - packaging_qty) + adjustments_qty['POLISHING']
    
    ready_qty = (
        (packaging_qty + qty_totals.get(TransactionType.KITTING_PRODUCE, 0)) - qty_totals.get(TransactionType.DISPATCH_OUT, 0)
    ) + adjustments_qty['READY']

    casting_weight = (weight_totals.get(TransactionType.CASTING_ENTRY, 0) - weight_totals.get(TransactionType.MACHINING_OUT, 0)) + adjustments_wt['CASTING']
    
    machining_weight = (weight_totals.get(TransactionType.MACHINING_IN, 0) - (
        weight_totals.get(TransactionType.POLISHING_OUT, 0) + 
        weight_totals.get(f"{TransactionType.KITTING_CONSUME}_MACHINING", 0)
    )) + adjustments_wt['MACHINING']
    
    raw_packaging_weight = weight_totals.get(TransactionType.PACKAGING_IN, 0)
    packaging_weight = max(0, raw_packaging_weight - dedicated_buffer_weight)
    
    polishing_weight = (weight_totals.get(TransactionType.POLISHING_IN, 0) - packaging_weight) + adjustments_wt['POLISHING']
    
    ready_weight = (
        (packaging_weight + weight_totals.get(TransactionType.KITTING_PRODUCE, 0)) - weight_totals.get(TransactionType.DISPATCH_OUT, 0)
    ) + adjustments_wt['READY']

    return {
        'casting_qty': casting_qty,
        'casting_weight': round(casting_weight, 3),
        'machining_qty': machining_qty,
        'machining_weight': round(machining_weight, 3),
        'polishing_qty': polishing_qty,
        'polishing_weight': round(polishing_weight, 3),
        'ready_qty': ready_qty,
        'ready_weight': round(ready_weight, 3),
    }
