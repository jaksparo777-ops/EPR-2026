from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from apps.master_data.models import LegalEntity

@login_required
def select_company(request):
    # If the user is locked to one company, enforce and auto-redirect
    if hasattr(request.user, 'company') and request.user.company:
        request.session['active_company_id'] = request.user.company.id
        return redirect('dashboard')

    if request.method == 'POST':
        company_id = request.POST.get('company_id')
        if company_id == 'global' and request.user.is_staff:
            request.session['active_company_id'] = 'global'
            return redirect('dashboard')

        if company_id:
            try:
                # Ensure the company exists
                LegalEntity.objects.get(id=company_id)
                request.session['active_company_id'] = int(company_id)
                return redirect('dashboard')
            except (ValueError, LegalEntity.DoesNotExist):
                pass

    companies = LegalEntity.objects.all().order_by('id')
    return render(request, 'select_company.html', {'companies': companies})
