from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Worker, JobWorker

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'role', 'company', 'is_staff', 'is_active')
    list_filter = ('role', 'company', 'is_staff', 'is_active')
    fieldsets = UserAdmin.fieldsets + (
        ('Custom Scope Info', {'fields': ('role', 'company')}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Custom Scope Info', {'fields': ('role', 'company')}),
    )

@admin.register(Worker)
class WorkerAdmin(admin.ModelAdmin):
    list_display = ('employee_id', 'name', 'company', 'process', 'salary_model', 'daily_rate', 'active')
    list_filter = ('company', 'process', 'salary_model', 'active')
    search_fields = ('employee_id', 'name')

@admin.register(JobWorker)
class JobWorkerAdmin(admin.ModelAdmin):
    list_display = ('jw_code', 'name', 'company', 'process', 'active')
    list_filter = ('company', 'process', 'active')
    search_fields = ('jw_code', 'name')
