from django.contrib.auth.models import AbstractUser
from django.db import models
from apps.master_data.models import LegalEntity

class CustomUser(AbstractUser):
    """
    Extends the default User model to support role-based access and multi-company scoping.
    """
    ROLE_CHOICES = [
        ('ADMIN', 'System Admin'),
        ('MANAGER', 'Production Manager'),
        ('OPERATOR', 'Casting Operator'),
        ('ACCOUNTANT', 'Accounts Manager'),
    ]

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='OPERATOR')
    company = models.ForeignKey(
        LegalEntity, 
        on_delete=models.SET_NULL, 
        blank=True, 
        null=True, 
        related_name="users",
        help_text="The active legal company this user belongs to. Leave empty for system-wide access."
    )

    class Meta:
        verbose_name = "User Account"
        verbose_name_plural = "User Accounts"

    def __str__(self):
        company_scope = self.company.name if self.company else "Global/All"
        return f"{self.username} ({self.get_role_display()} - {company_scope})"


class ProcessType(models.TextChoices):
    CASTING = "casting", "Casting"
    MACHINING = "machining", "Machining"
    POLISHING = "polishing", "Polishing"
    PACKAGING = "packaging", "Packaging"


class SalaryModel(models.TextChoices):
    DAILY = "DAILY", "Daily Wage"
    FIXED = "FIXED", "Monthly Fixed"
    HOURLY = "HOURLY", "Hourly/Time Based"


class Worker(models.Model):
    name = models.CharField(max_length=100)
    company = models.ForeignKey(LegalEntity, on_delete=models.PROTECT, related_name="workers")
    salary_model = models.CharField(max_length=20, choices=SalaryModel.choices, default=SalaryModel.DAILY)
    daily_rate = models.FloatField(default=0)
    monthly_fixed_salary = models.FloatField(default=0)
    overtime_rate = models.FloatField(default=0)
    monthly_allowance = models.FloatField(default=0)
    process = models.CharField(max_length=50, choices=ProcessType.choices, default="machining")
    phone = models.CharField(max_length=20, blank=True, null=True)
    employee_id = models.CharField(max_length=50, blank=True, null=True, unique=True)
    designation = models.CharField(max_length=100, blank=True, null=True)
    joining_date = models.DateField(blank=True, null=True)
    standard_shift_hours = models.FloatField(default=8)
    identity_number = models.CharField(max_length=100, blank=True, null=True, help_text="Aadhar / Govt ID")
    emergency_contact_name = models.CharField(max_length=100, blank=True, null=True)
    emergency_contact_phone = models.CharField(max_length=20, blank=True, null=True)
    blood_group = models.CharField(max_length=10, blank=True, null=True)
    casting_rate_per_kg = models.FloatField(default=0.0)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.employee_id or not str(self.employee_id).strip():
            if self.id:
                self.employee_id = f"EMP-{1000 + self.id}"
            else:
                last_w = Worker.objects.order_by("-id").first()
                base_id = (last_w.id + 1) if last_w else 1
                while True:
                    code = f"EMP-{1000 + base_id}"
                    if not Worker.objects.filter(employee_id=code).exists():
                        self.employee_id = code
                        break
                    base_id += 1
        if self.overtime_rate == 0 and self.salary_model == "DAILY" and self.standard_shift_hours > 0:
            self.overtime_rate = round(self.daily_rate / self.standard_shift_hours, 2)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.employee_id or '---'} - {self.name} ({self.company.name})"


class JobWorker(models.Model):
    name = models.CharField(max_length=100)
    company = models.ForeignKey(LegalEntity, on_delete=models.PROTECT, related_name="job_workers")
    process = models.CharField(max_length=50, choices=ProcessType.choices)
    phone = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    gst_number = models.CharField(max_length=15, blank=True, null=True)
    active = models.BooleanField(default=True)
    jw_code = models.CharField(max_length=50, blank=True, null=True, unique=True)
    casting_rate_per_kg = models.FloatField(default=0.0)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.jw_code or not str(self.jw_code).strip():
            last_jw = JobWorker.objects.order_by("-id").first()
            base_id = (last_jw.id + 1) if last_jw else 1
            while True:
                code = f"JW-{1000 + base_id}"
                if not JobWorker.objects.filter(jw_code=code).exists():
                    self.jw_code = code
                    break
                base_id += 1
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.jw_code or '---'} - {self.name} ({self.company.name})"
