from django.shortcuts import redirect
from django.urls import resolve, Resolver404
from apps.master_data.models import LegalEntity

class CompanyScopeMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # 1. Bypass check for unauthenticated users, admin console, static/media, or auth routes
        if not request.user.is_authenticated:
            return self.get_response(request)

        path = request.path
        
        # Exclude Django Admin, Static, Media, select-company, login and logout urls from interception
        exempt_prefixes = [
            '/admin/',
            '/static/',
            '/media/',
            '/login/',
            '/logout/',
            '/select-company/'
        ]
        
        if any(path.startswith(prefix) for prefix in exempt_prefixes):
            return self.get_response(request)

        # 2. Check user role scoping (if user is locked to one company, enforce it)
        if hasattr(request.user, 'company') and request.user.company:
            request.company = request.user.company
            request.session['active_company_id'] = request.user.company.id
            return self.get_response(request)

        # 3. Handle session-based scoping for managers/admins
        active_company_id = request.session.get('active_company_id')
        if not active_company_id:
            return redirect('select_company')

        if active_company_id == 'global':
            request.company = None
            return self.get_response(request)

        try:
            request.company = LegalEntity.objects.get(id=active_company_id)
        except LegalEntity.DoesNotExist:
            # Session points to an invalid company, clear and redirect
            if 'active_company_id' in request.session:
                del request.session['active_company_id']
            return redirect('select_company')

        return self.get_response(request)
