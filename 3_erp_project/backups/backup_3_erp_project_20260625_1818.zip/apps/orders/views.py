from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from .models import SalesOrder, SalesOrderItem, Dispatch, DispatchItem
from apps.master_data.models import Client, Item
from apps.production.models import StockTransaction, TransactionType

@login_required
def orders_board(request):
    orders = SalesOrder.objects.prefetch_related('items', 'items__item').select_related('client').all()
    if request.company:
        orders = orders.filter(client__company=request.company)
    # Sort orders: URGENT first, then OPEN/PARTIAL first, then by promised_date
    orders = sorted(
        orders,
        key=lambda x: (
            0 if x.priority == 'URGENT' else 1,
            0 if x.status in [SalesOrder.OrderStatus.OPEN, SalesOrder.OrderStatus.PARTIAL] else 1,
            x.promised_date
        )
    )
    
    # Calculate telemetry metrics
    import datetime
    today = datetime.date.today()
    active_count = sum(1 for o in orders if o.status in [SalesOrder.OrderStatus.OPEN, SalesOrder.OrderStatus.PARTIAL])
    ready_count = sum(1 for o in orders if o.status == SalesOrder.OrderStatus.OPEN and o.readiness_percentage >= 100)
    wip_count = sum(1 for o in orders if o.status == SalesOrder.OrderStatus.OPEN and o.readiness_percentage < 100 and o.coverage_percentage > 0)
    completed_count = sum(1 for o in orders if o.status == SalesOrder.OrderStatus.COMPLETED)

    for o in orders:
        o.days_left = (o.promised_date - today).days
        o.abs_days_left = abs(o.days_left)



    if request.company:
        clients = Client.objects.filter(company=request.company)
        if request.company.id == 2:
            items = Item.objects.filter(Q(company=request.company) | Q(client__name='OM'))
        else:
            items = Item.objects.filter(company=request.company)
            if request.company.id == 1:
                items = items.filter(casting_required=True)
        recent_orders = SalesOrder.objects.prefetch_related('items', 'items__item').select_related('client').filter(client__company=request.company).order_by('-id')[:10]
        dispatches = Dispatch.objects.prefetch_related('items', 'items__item').select_related('client', 'sales_order').filter(client__company=request.company).order_by('-id')[:20]
    else:
        clients = Client.objects.all()
        items = Item.objects.all()
        recent_orders = SalesOrder.objects.prefetch_related('items', 'items__item').select_related('client').order_by('-id')[:10]
        dispatches = Dispatch.objects.prefetch_related('items', 'items__item').select_related('client', 'sales_order').order_by('-id')[:20]

    return render(request, 'orders_board.html', {
        'orders': orders,
        'clients': clients,
        'items': items,
        'recent_orders': recent_orders,
        'dispatches': dispatches,
        'kpi': {
            'active': active_count,
            'ready': ready_count,
            'wip': wip_count,
            'completed': completed_count
        }
    })


@login_required
def order_details_api(request, order_id):
    order = get_object_or_404(SalesOrder.objects.prefetch_related('items', 'items__item').select_related('client'), id=order_id)
    items_data = []
    from apps.production.models import Carton
    for item in order.items.all():
        # Get ready cartons specifically containing this item
        cartons_qs = Carton.objects.filter(status='READY', items__item=item.item)
        
        # Calculate ready stock counts by carton type
        reg_cartons_count = 0
        box_cartons_count = 0
        reg_cartons_pieces = 0
        box_cartons_pieces = 0
        
        for c in cartons_qs:
            # Let's see how much of this item is inside the carton
            ci = c.items.filter(item=item.item).first()
            if ci:
                is_box = "BOX" in (c.carton_label or '').upper() or "LOT" in (c.carton_label or '').upper()
                if is_box:
                    box_cartons_count += 1
                    box_cartons_pieces += ci.quantity
                else:
                    reg_cartons_count += 1
                    reg_cartons_pieces += ci.quantity
                    
        # Total ready pieces from physical Carton models
        total_cartons_pieces = reg_cartons_pieces + box_cartons_pieces
        total_ready_pcs = item.ready_stock
        
        # Loose pieces = total ready stock - carton-allocated pieces
        loose_pieces = max(0, total_ready_pcs - total_cartons_pieces)

        items_data.append({
            'id': item.id,
            'item_id': item.item.id,
            'item_code': item.item.code,
            'item_name': item.item.name,
            'ordered_qty': item.ordered_quantity,
            'dispatched_qty': item.dispatched_quantity,
            'remaining_qty': item.remaining_quantity,
            'ready_stock': total_ready_pcs,
            'pipeline_qty': item.pipeline_quantity,
            'rate': item.rate_per_piece,
            'remarks': item.remarks or '',
            'stock_details': {
                'reg_cartons_count': reg_cartons_count,
                'reg_cartons_pieces': reg_cartons_pieces,
                'box_cartons_count': box_cartons_count,
                'box_cartons_pieces': box_cartons_pieces,
                'loose_pieces': loose_pieces
            }
        })
    
    return JsonResponse({
        'id': order.id,
        'order_number': order.order_number,
        'client_id': order.client.id,
        'client_name': order.client.name,
        'packing_preference': order.client.packing_preference,
        'external_po_number': order.external_po_number,
        'order_date': order.order_date.strftime('%Y-%m-%d'),
        'promised_date': order.promised_date.strftime('%Y-%m-%d'),
        'priority': order.priority,
        'status': order.get_status_display(),
        'status_code': order.status,
        'notes': order.notes or '',
        'readiness_percentage': order.readiness_percentage,
        'coverage_percentage': order.coverage_percentage,
        'items': items_data
    })

@login_required
@transaction.atomic
def dispatch_order(request, order_id):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Invalid request method.'}, status=400)
    
    order = get_object_or_404(SalesOrder, id=order_id)
    
    # Check if this order is already completed
    if order.status == SalesOrder.OrderStatus.COMPLETED:
        return JsonResponse({'success': False, 'error': 'This order is already completed.'}, status=400)
        
    dispatch_type = request.POST.get('dispatch_type', 'partial') # 'full' or 'partial'
    notes = request.POST.get('notes', '')
    
    dispatch_items_data = []
    
    if dispatch_type == 'full':
        # Dispatch the remaining needed quantity for all items, capped by ready stock
        for item in order.items.all():
            qty = min(item.remaining_quantity, item.ready_stock)
            if qty > 0:
                dispatch_items_data.append((item.item, qty))
    else:
        # Partial dispatch with custom quantities from POST
        for item in order.items.all():
            qty_str = request.POST.get(f'qty_{item.id}', '0')
            try:
                qty = int(qty_str)
            except ValueError:
                qty = 0
            if qty > item.remaining_quantity:
                return JsonResponse({'success': False, 'error': f'Cannot dispatch more than remaining needed quantity ({item.remaining_quantity}) for item {item.item.name}.'}, status=400)
            if qty > item.ready_stock:
                return JsonResponse({'success': False, 'error': f'Cannot dispatch more than available ready stock ({item.ready_stock}) for item {item.item.name}.'}, status=400)
            if qty > 0:
                dispatch_items_data.append((item.item, qty))
                
    if not dispatch_items_data:
        return JsonResponse({'success': False, 'error': 'No items to dispatch or insufficient ready stock.'}, status=400)
        
    from apps.production.models import Carton, CartonItem
    
    # Create the Dispatch record
    dispatch = Dispatch.objects.create(
        sales_order=order,
        client=order.client,
        notes=notes
    )
    
    # Process each requested item
    for db_item, qty in dispatch_items_data:
        weight = qty * float(db_item.machining_weight or 0.0)
        
        # Symmetrically create DispatchItem record
        DispatchItem.objects.create(
            dispatch=dispatch,
            item=db_item,
            quantity=qty,
            weight=weight
        )
        
        # Intelligent carton deduction strategy according to Client preferences
        pref = order.client.packing_preference
        remaining_to_deduct = qty
        
        # 1. Box Lot cartons matching item
        box_cartons = list(Carton.objects.filter(status='READY', items__item=db_item).order_by('created_at'))
        # Filter for actual box labels
        box_cartons = [c for c in box_cartons if "BOX" in (c.carton_label or '').upper() or "LOT" in (c.carton_label or '').upper()]
        
        # 2. Regular cartons matching item
        reg_cartons = list(Carton.objects.filter(status='READY', items__item=db_item).order_by('created_at'))
        reg_cartons = [c for c in reg_cartons if c not in box_cartons]
        
        # Prioritize queues based on Client Preference
        primary_queue = []
        secondary_queue = []
        
        if pref == 'BOX_PREF':
            primary_queue = box_cartons
            secondary_queue = reg_cartons
        elif pref == 'REG_PREF':
            primary_queue = reg_cartons
            secondary_queue = box_cartons
        elif pref == 'BOX_STRICT':
            primary_queue = box_cartons
            secondary_queue = []  # No fallback allowed
        elif pref == 'REG_STRICT':
            primary_queue = reg_cartons
            secondary_queue = []  # No fallback allowed
        else:  # ANY / flexible
            # Fallback to whatever carton type we have the most of or first available
            primary_queue = box_cartons + reg_cartons
            secondary_queue = []
            
        # Helper logic to deduct cartons from chosen queue
        def deduct_from_queue(queue):
            nonlocal remaining_to_deduct
            for carton in queue:
                if remaining_to_deduct <= 0:
                    break
                ci = carton.items.filter(item=db_item).first()
                if ci and ci.quantity <= remaining_to_deduct:
                    # Mark entire carton as dispatched cleanly!
                    carton.status = Carton.CartonStatus.DISPATCHED
                    carton.client = order.client
                    carton.dispatched_at = timezone.now()
                    carton.save()
                    remaining_to_deduct -= ci.quantity
                    
        # Apply primary queue then secondary queue
        deduct_from_queue(primary_queue)
        deduct_from_queue(secondary_queue)
        
        # Create a single transaction log representing this item's dispatch
        StockTransaction.objects.create(
            item=db_item,
            transaction_type=TransactionType.DISPATCH_OUT,
            client=order.client,
            quantity=qty,
            weight=weight,
            notes=f"Dispatched {qty} pcs for PO {order.external_po_number} via {dispatch.dispatch_number} (Intelligent Pref Fulfill: {pref})"
        )
        
    # Recalculate status of the SalesOrder
    total_remaining = sum(item.remaining_quantity for item in order.items.all())
    if total_remaining == 0:
        order.status = SalesOrder.OrderStatus.COMPLETED
    else:
        order.status = SalesOrder.OrderStatus.PARTIAL
    order.save()
    
    return JsonResponse({
        'success': True,
        'dispatch_number': dispatch.dispatch_number,
        'message': f'Successfully created dispatch {dispatch.dispatch_number}.'
    })

@login_required
@transaction.atomic
def create_order_view(request):
    if request.method == 'POST':
        client_id = request.POST.get('client')
        external_po_number = request.POST.get('external_po_number')
        promised_date = request.POST.get('promised_date')
        priority = request.POST.get('priority', 'NORMAL')
        notes = request.POST.get('notes', '')
        po_id = request.POST.get('po_id')

        if not client_id:
            messages.error(request, "Client is required.")
            return redirect('/orders/?tab=create')

        if not promised_date or not promised_date.strip():
            import datetime
            promised_date = (datetime.date.today() + datetime.timedelta(days=10)).strftime('%Y-%m-%d')


        client = get_object_or_404(Client, id=client_id)

        if po_id:
            order = get_object_or_404(SalesOrder, id=po_id)
        else:
            order = None

        # Parse dynamic item rows
        item_ids = request.POST.getlist('item_id[]')
        quantities = request.POST.getlist('quantity[]')
        remarks_list = request.POST.getlist('remarks[]')

        # Perform quantities verification against dispatched counts first
        if order:
            dispatched_map = {item.item.id: item.dispatched_quantity for item in order.items.all()}
            for i in range(len(item_ids)):
                if not item_ids[i]:
                    continue
                try:
                    item_id = int(item_ids[i])
                    quantity = int(quantities[i])
                except (ValueError, IndexError):
                    continue
                
                dispatched_qty = dispatched_map.get(item_id, 0)
                if quantity < dispatched_qty:
                    item_obj = get_object_or_404(Item, id=item_id)
                    messages.error(request, f"Cannot reduce ordered quantity below dispatched quantity ({dispatched_qty} pcs) for item {item_obj.code}.")
                    return redirect('/orders/?tab=create')

        # Create or update SalesOrder
        if order:
            order.client = client
            order.external_po_number = external_po_number
            order.promised_date = promised_date
            order.priority = priority
            order.notes = notes
            order.save()
            
            # Delete old items
            order.items.all().delete()
        else:
            order = SalesOrder.objects.create(
                client=client,
                external_po_number=external_po_number,
                promised_date=promised_date,
                priority=priority,
                notes=notes
            )

        created_items = 0
        for i in range(len(item_ids)):
            if not item_ids[i]:
                continue
            try:
                item_id = int(item_ids[i])
                quantity = int(quantities[i])
                remarks = remarks_list[i] if i < len(remarks_list) else ''
            except (ValueError, IndexError):
                continue

            if quantity > 0:
                item = get_object_or_404(Item, id=item_id)
                SalesOrderItem.objects.create(
                    sales_order=order,
                    item=item,
                    ordered_quantity=quantity,
                    rate_per_piece=0.0,
                    remarks=remarks
                )
                created_items += 1

        if created_items == 0:
            if not po_id:
                order.delete()
            messages.error(request, "You must add at least one item with quantity greater than 0.")
            return redirect('/orders/?tab=create')

        if po_id:
            messages.success(request, f"Successfully updated Customer PO {order.order_number} for {client.name}.")
        else:
            messages.success(request, f"Successfully created Customer PO {order.order_number} for {client.name}.")
        return redirect('orders_board')

    # GET Request
    return redirect('/orders/?tab=create')


@login_required
def delete_order(request, order_id):
    if not request.user.is_staff:
        messages.error(request, "Permission denied.")
        return redirect('orders_board')
        
    order = get_object_or_404(SalesOrder, id=order_id)
    if order.dispatches.exists():
        messages.error(request, "Cannot delete PO with active dispatch history.")
        return redirect('orders_board')
        
    order_num = order.order_number
    # Cascade delete items
    order.items.all().delete()
    order.delete()
    messages.success(request, f"Customer PO {order_num} deleted successfully.")
    return redirect('orders_board')
