from django.db import models

class LegalEntity(models.Model):
    """
    Represents a company or business unit (e.g., Company 1: Casting, Company 2: Finishing).
    """
    name = models.CharField(max_length=255, unique=True)
    gst_number = models.CharField(max_length=15, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField()
    letterhead_title = models.CharField(max_length=255, blank=True, null=True)
    
    # Workflow Delegation Flags
    handles_casting = models.BooleanField(default=True)
    handles_machining = models.BooleanField(default=False)
    handles_polishing = models.BooleanField(default=False)
    handles_packaging = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Legal Entity"
        verbose_name_plural = "Legal Entities"

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Categories"


class Material(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Materials"


class Client(models.Model):
    """
    Represents a client or customer. Scoped strictly to a LegalEntity (Company).
    """
    name = models.CharField(max_length=255)
    client_code = models.CharField(max_length=50, blank=True, null=True, unique=True)
    company = models.ForeignKey(LegalEntity, on_delete=models.PROTECT, related_name="clients")
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    PACKING_CHOICES = [
        ('BOX_PREF', 'Box Lot Preferred & Flexible'),
        ('REG_PREF', 'Regular Preferred & Flexible'),
        ('BOX_STRICT', 'Strict Box Lot Only'),
        ('REG_STRICT', 'Strict Regular Only'),
        ('ANY', 'Fully Flexible / Any'),
    ]
    packing_preference = models.CharField(max_length=20, choices=PACKING_CHOICES, default='ANY')

    gst_number = models.CharField(max_length=15, blank=True, null=True)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('name', 'company')
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.client_code or not str(self.client_code).strip():
            last_cl = Client.objects.order_by("-id").first()
            base_id = (last_cl.id + 1) if last_cl else 1
            while True:
                code = f"CL-{1000 + base_id}"
                if not Client.objects.filter(client_code=code).exists():
                    self.client_code = code
                    break
                base_id += 1
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.client_code or '---'} - {self.name} ({self.company.name})"


class Warehouse(models.Model):
    """
    Represents a physical or process warehouse stage (e.g., CASTING, MACHINING, READY).
    """
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=100)
    company = models.ForeignKey(LegalEntity, on_delete=models.PROTECT, blank=True, null=True, related_name="warehouses")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} [{self.code}]"


class Item(models.Model):
    """
    Represents raw material, component, or finished set.
    Can be scoped to a company or be a global item.
    """
    CATEGORY_CHOICES = [
        ('BRASS', 'Brass'),
        ('MORTAR', 'Mortar'),
        ('PESTLE', 'Pestle'),
        ('CHOPPING_BOARD', 'Chopping Board'),
        ('OTHER', 'Other'),
    ]

    PROCESS_CHOICES = [
        ('MACHINING', 'Machining'),
        ('POLISHING', 'Polishing'),
        ('PACKAGING', 'Packaging'),
        ('NONE', 'None'),
    ]

    code = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default='OTHER')
    sub_category = models.CharField(max_length=100, blank=True, null=True)
    material = models.CharField(max_length=100, default='OTHER', blank=True, null=True)
    variant = models.CharField(max_length=100, blank=True, null=True)
    item_type = models.CharField(max_length=100, default='REGULAR')
    notes = models.TextField(blank=True, null=True)
    company = models.ForeignKey(LegalEntity, on_delete=models.PROTECT, blank=True, null=True, related_name="items")
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, blank=True, null=True, related_name="items")
    
    # Process & Weight Route sheet
    casting_required = models.BooleanField(default=True)
    machining_required = models.BooleanField(default=False)
    polishing_required = models.BooleanField(default=False)
    packing_required = models.BooleanField(default=False)
    
    casting_weight = models.FloatField(default=0.0)
    machining_weight = models.FloatField(default=0.0)
    
    # Packing specs
    lot_size = models.IntegerField(default=1)
    lot_with_box = models.IntegerField(default=1)
    rate_per_piece = models.FloatField(default=0.0)
    
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} - {self.name}"

    def calculate_cartons_and_loose(self, quantity):
        divisor = self.lot_with_box or self.lot_size or 1
        if self.lot_size and self.lot_with_box:
            if quantity % self.lot_size == 0:
                divisor = self.lot_size
            elif quantity % self.lot_with_box == 0:
                divisor = self.lot_with_box
            else:
                rem_size = quantity % self.lot_size
                rem_box = quantity % self.lot_with_box
                if rem_size < rem_box:
                    divisor = self.lot_size
                else:
                    divisor = self.lot_with_box
                    
        cartons = quantity // divisor if divisor > 0 else 0
        loose = quantity % divisor if divisor > 0 else quantity
        return cartons, loose


class ItemComposition(models.Model):
    """
    Defines Bill of Materials (BOM) parent-to-component sets.
    """
    parent_item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='components')
    component_item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='parent_sets')
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ('parent_item', 'component_item')

    def __str__(self):
        return f"{self.quantity} x {self.component_item.name} in {self.parent_item.name}"


class MaintenanceSettings(models.Model):
    """
    Database settings for scheduling auto-backup and auto-deletion in ERP.
    """
    auto_backup_enabled = models.BooleanField(default=False)
    auto_backup_frequency = models.CharField(
        max_length=20,
        choices=[('daily', 'Daily'), ('weekly', 'Weekly'), ('monthly', 'Monthly')],
        default='weekly'
    )
    backup_retention_count = models.IntegerField(default=10)
    last_backup_run = models.DateTimeField(null=True, blank=True)

    auto_delete_enabled = models.BooleanField(default=False)
    auto_delete_frequency = models.CharField(
        max_length=20,
        choices=[('4_months', 'Every 4 Months'), ('6_months', 'Half-Year (6 Months)'), ('1_year', 'Every 1 Year')],
        default='6_months'
    )
    last_delete_run = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Maintenance Settings"
        verbose_name_plural = "Maintenance Settings"

    def __str__(self):
        return "System Maintenance Settings"


class MaintenanceLog(models.Model):
    """
    Immutable audit trail for ERP maintenance events.
    """
    timestamp = models.DateTimeField(auto_now_add=True)
    event_type = models.CharField(
        max_length=20,
        choices=[
            ('backup', 'Auto-Backup'),
            ('delete', 'Auto-Delete Purge'),
            ('audit_fail', 'Safety Audit Blocked'),
            ('restore', 'Database Restoration'),
            ('reset', 'Factory Reset')
        ]
    )
    status = models.CharField(
        max_length=20,
        choices=[('success', 'Success'), ('failed', 'Failed'), ('skipped', 'Skipped')]
    )
    message = models.TextField()
    details = models.TextField(blank=True, default='')

    class Meta:
        verbose_name = "Maintenance Log"
        verbose_name_plural = "Maintenance Logs"
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.get_event_type_display()} - {self.status} on {self.timestamp.strftime('%Y-%m-%d %H:%M')}"
