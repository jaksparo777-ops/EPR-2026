import csv
import io
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.db import transaction
from django.contrib.admin.views.decorators import staff_member_required
from django.core import serializers
from django.utils import timezone
from django.urls import reverse

from apps.master_data.models import (
    LegalEntity, Client, Item, ItemComposition, Category, Material,
    Warehouse, MaintenanceSettings, MaintenanceLog
)
from apps.authentication.models import Worker, JobWorker, ProcessType, SalaryModel
from apps.production.models import (
    ItemWorkerAllocation, StockTransaction, Attendance, Loan,
    LaborPayment, Carton, CartonItem
)
from apps.orders.models import SalesOrder, SalesOrderItem

def to_float(val, default_val=0.0):
    if val is None or str(val).strip() == "":
        return default_val
    try:
        return float(val)
    except ValueError:
        return default_val

def to_int(val, default_val=0):
    if val is None or str(val).strip() == "":
        return default_val
    try:
        return int(float(val))
    except ValueError:
        return default_val

def to_bool(val):
    if val is None:
        return False
    val_str = str(val).strip().lower()
    return val_str in ('true', '1', 'yes', 'y', 't', 'active')

def parse_rates_string(rates_str):
    """
    Parses a complex multi-rate string (e.g. K0:8,K1:8,K2:9 or D0,D1:5.5) and 
    returns a dict of {item_code: rate_float}. Supports period, semicolon, and comma groupings.
    """
    allocs = {}
    if not rates_str:
        return allocs
    
    normalized = str(rates_str).replace(';', '.').strip()
    if '.' not in normalized and ',' in normalized:
        parts = normalized.split(',')
        if all(':' in p for p in parts):
            normalized = '.'.join(parts)
            
    groups = [g.strip() for g in normalized.split('.') if g.strip()]
    for group in groups:
        if ':' not in group:
            continue
        items_part, rate_part = group.rsplit(':', 1)
        try:
            rate_val = float(rate_part.strip())
        except ValueError:
            continue
        
        item_codes = [i.strip() for i in items_part.split(',') if i.strip()]
        for code in item_codes:
            allocs[code.upper()] = rate_val
    return allocs

@staff_member_required
def download_template(request, template_type):
    """
    Generates and returns an empty, ready-to-use CSV template for bulk imports.
    """
    response = HttpResponse(content_type='text/csv')
    
    if template_type == 'items':
        response['Content-Disposition'] = 'attachment; filename="items_import_template.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Item Code*', 'Item Name*', 'Category (BRASS/MORTAR/PESTLE/CHOPPING_BOARD/OTHER)*', 'Sub Category', 'Material', 'Variant',
            'Casting Weight (kg)', 'Machining Weight (kg)', 'Casting Required (YES/NO)', 'Machining Required (YES/NO)',
            'Polishing Required (YES/NO)', 'Packing Required (YES/NO)', 'Lot Size (pcs)', 'Lot Weight With Box (kg)', 'Standard Rate per Piece (₹)',
            'Company Scope (NC/OM/GLOBAL)*', 'Client Scope', 'Worker Piece-Rates (WorkerName:Rate; WorkerName:Rate)'
        ])
        writer.writerow([
            'BR-001', '6 Inch Brass Pestle', 'PESTLE', 'Brass Classic', 'BRASS', 'Standard Finish',
            '1.45', '1.30', 'YES', 'YES', 'YES', 'YES', '24', '24', '12.50',
            'GLOBAL', 'Mahadev Metal Works', 'Ram Singh:12.50; Shyam Lal:10.00'
        ])
    elif template_type == 'clients':
        response['Content-Disposition'] = 'attachment; filename="clients_import_template.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Client Name*', 'GSTIN Number', 'Phone', 'Email', 'City', 'Billing Address', 'Company Scope (NC/OM)*', 'Client Code (Leave blank for auto-generate)'
        ])
        writer.writerow([
            'Mahadev Metal Works', '07AAAAA1111A1Z1', '9876543210', 'billing@mahadev.com', 'Delhi', 'Sector 5, Rohini', 'NC', ''
        ])
    elif template_type == 'workers':
        response['Content-Disposition'] = 'attachment; filename="employees_import_template.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Name*', 'Phone', 'Company Scope (NC/OM)*', 'Worker Type (EMPLOYEE/JOB_WORKER)*', 'Department Process (casting/machining/polishing/packaging)*', 'Salary Type (DAILY/FIXED - Employees only)',
            'Daily Wage Rate (₹ - Daily Employees)', 'Monthly Fixed Salary (₹ - Fixed Employees)', 'Casting Piece-Rate (₹/kg)', 'Designation',
            'Vendor Address (Job Workers)', 'Vendor Email (Job Workers)', 'Vendor GSTIN (Job Workers)', 'Worker Code (Leave blank for auto-generate)',
            'Rates (ItemCode:Rate,ItemCode:Rate,...)'
        ])
        writer.writerow([
            'Ram Singh', '9988776655', 'NC', 'EMPLOYEE', 'machining', 'DAILY',
            '500.0', '0.0', '12.0', 'Lathe Machine Operator', '', '', '', '', 'K0:8,K1:8,K2:9'
        ])
        writer.writerow([
            'Shyam Lal', '9876543222', 'OM', 'JOB_WORKER', 'polishing', '',
            '0.0', '0.0', '0.0', 'Buffing Expert', 'Street B', 'shyam@gmail.com', '07BBBBB1111B1Z2', '', 'D0,D1,D2,D3,D4,D5,D6,D7:5.5'
        ])
    elif template_type == 'bom':
        response['Content-Disposition'] = 'attachment; filename="bom_import_template.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Parent Item Code*', 'Component Item Code*', 'Quantity*'
        ])
        writer.writerow([
            'SET-001', 'COMP-001', '2'
        ])
        writer.writerow([
            'SET-001', 'COMP-002', '1'
        ])
    elif template_type == 'po':
        response['Content-Disposition'] = 'attachment; filename="po_import_template.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'PO Number*', 'Client Name or Code*', 'Order Date (YYYY-MM-DD)*', 'Promised Date (YYYY-MM-DD)*', 'Priority (URGENT/NORMAL)*', 'Item Code*', 'Ordered Qty*', 'Rate per Piece (₹)*', 'Remarks'
        ])
        writer.writerow([
            'PO-2026-001', 'Mahadev Metal Works', '2026-05-30', '2026-06-15', 'NORMAL', 'BR-001', '100', '12.50', 'First trial shipment'
        ])
        writer.writerow([
            'PO-2026-001', 'Mahadev Metal Works', '2026-05-30', '2026-06-15', 'NORMAL', 'BR-002', '50', '15.00', ''
        ])
    else:
        return HttpResponse("Invalid template type", status=400)
        
    return response

@staff_member_required
def export_current_data(request, template_type):
    """
    Exports current active database entries to a CSV file matching the import templates.
    """
    response = HttpResponse(content_type='text/csv')
    
    if template_type == 'items':
        response['Content-Disposition'] = 'attachment; filename="items_current_export.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Item Code*', 'Item Name*', 'Category (BRASS/MORTAR/PESTLE/CHOPPING_BOARD/OTHER)*', 'Sub Category', 'Material', 'Variant',
            'Casting Weight (kg)', 'Machining Weight (kg)', 'Casting Required (YES/NO)', 'Machining Required (YES/NO)',
            'Polishing Required (YES/NO)', 'Packing Required (YES/NO)', 'Lot Size (pcs)', 'Lot Weight With Box (kg)', 'Standard Rate per Piece (₹)',
            'Company Scope (NC/OM/GLOBAL)*', 'Client Scope', 'Worker Piece-Rates (WorkerName:Rate; WorkerName:Rate)'
        ])
        for item in Item.objects.all():
            allocs = ItemWorkerAllocation.objects.filter(item=item)
            rates_list = []
            for a in allocs:
                w_name = a.worker.name if a.worker else (a.job_worker.name if a.job_worker else "")
                if w_name:
                    rates_list.append(f"{w_name}:{a.rate_per_piece}")
            rates_str = "; ".join(rates_list)
            
            writer.writerow([
                item.code,
                item.name,
                item.category,
                item.sub_category or "",
                item.material or "OTHER",
                item.variant or "",
                item.casting_weight,
                item.machining_weight,
                "YES" if item.casting_required else "NO",
                "YES" if item.machining_required else "NO",
                "YES" if item.polishing_required else "NO",
                "YES" if item.packing_required else "NO",
                item.lot_size,
                item.lot_with_box,
                item.rate_per_piece,
                item.company.name if item.company else "GLOBAL",
                item.client.name if item.client else "",
                rates_str
            ])
            
    elif template_type == 'clients':
        response['Content-Disposition'] = 'attachment; filename="clients_current_export.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Client Name*', 'GSTIN Number', 'Phone', 'Email', 'City', 'Billing Address', 'Company Scope (NC/OM)*', 'Client Code (Leave blank for auto-generate)'
        ])
        for cl in Client.objects.all():
            writer.writerow([
                cl.name,
                cl.gst_number or "",
                cl.phone or "",
                cl.email or "",
                cl.city or "",
                cl.address or "",
                cl.company.name if cl.company else "",
                cl.client_code or ""
            ])
            
    elif template_type == 'workers':
        response['Content-Disposition'] = 'attachment; filename="employees_current_export.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Name*', 'Phone', 'Company Scope (NC/OM)*', 'Worker Type (EMPLOYEE/JOB_WORKER)*', 'Department Process (casting/machining/polishing/packaging)*', 'Salary Type (DAILY/FIXED - Employees only)',
            'Daily Wage Rate (₹ - Daily Employees)', 'Monthly Fixed Salary (₹ - Fixed Employees)', 'Casting Piece-Rate (₹/kg)', 'Designation',
            'Vendor Address (Job Workers)', 'Vendor Email (Job Workers)', 'Vendor GSTIN (Job Workers)', 'Worker Code (Leave blank for auto-generate)',
            'Rates (ItemCode:Rate,ItemCode:Rate,...)'
        ])
        # Export Direct Workers
        for w in Worker.objects.all():
            allocs = ItemWorkerAllocation.objects.filter(worker=w)
            rates_list = []
            for a in allocs:
                rates_list.append(f"{a.item.code}:{a.rate_per_piece}")
            rates_str = ",".join(rates_list)
            
            writer.writerow([
                w.name,
                w.phone or "",
                w.company.name if w.company else "",
                'EMPLOYEE',
                w.process,
                w.salary_model,
                w.daily_rate,
                w.monthly_fixed_salary,
                w.casting_rate_per_kg,
                w.designation or "",
                "", # address
                "", # email
                "", # gst_number
                w.employee_id or "",
                rates_str
            ])
        # Export JobWorkers
        for jw in JobWorker.objects.all():
            allocs = ItemWorkerAllocation.objects.filter(job_worker=jw)
            rates_list = []
            for a in allocs:
                rates_list.append(f"{a.item.code}:{a.rate_per_piece}")
            rates_str = ",".join(rates_list)
            
            writer.writerow([
                jw.name,
                jw.phone or "",
                jw.company.name if jw.company else "",
                'JOB_WORKER',
                jw.process,
                "", # salary model
                0.0, # daily rate
                0.0, # monthlyfixed
                jw.casting_rate_per_kg,
                "Job Worker", # designation
                jw.address or "",
                jw.email or "",
                jw.gst_number or "",
                jw.jw_code or "",
                rates_str
            ])
    elif template_type == 'bom':
        response['Content-Disposition'] = 'attachment; filename="bom_current_export.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'Parent Item Code*', 'Component Item Code*', 'Quantity*'
        ])
        for comp in ItemComposition.objects.all().select_related('parent_item', 'component_item'):
            writer.writerow([
                comp.parent_item.code,
                comp.component_item.code,
                comp.quantity
            ])
    elif template_type == 'po':
        response['Content-Disposition'] = 'attachment; filename="po_current_export.csv"'
        writer = csv.writer(response)
        writer.writerow([
            'PO Number*', 'Client Name or Code*', 'Order Date (YYYY-MM-DD)*', 'Promised Date (YYYY-MM-DD)*', 'Priority (URGENT/NORMAL)*', 'Item Code*', 'Ordered Qty*', 'Rate per Piece (₹)*', 'Remarks'
        ])
        for item in SalesOrderItem.objects.all().select_related('sales_order', 'sales_order__client', 'item'):
            writer.writerow([
                item.sales_order.external_po_number,
                item.sales_order.client.client_code or item.sales_order.client.name,
                item.sales_order.order_date.strftime("%Y-%m-%d") if item.sales_order.order_date else "",
                item.sales_order.promised_date.strftime("%Y-%m-%d") if item.sales_order.promised_date else "",
                item.sales_order.priority,
                item.item.code,
                item.ordered_quantity,
                item.rate_per_piece,
                item.remarks or ""
            ])
    else:
        return HttpResponse("Invalid template type", status=400)
        
    return response


def run_financial_audit(cut_off_date=None):
    from apps.production.models import Loan, Carton
    blockers = []
    
    # 1. Outstanding Worker/JobWorker Loans
    unpaid_loans = Loan.objects.filter(remaining_balance__gt=0, is_active=True)
    for loan in unpaid_loans:
        name = loan.worker.name if loan.worker else (loan.job_worker.name if loan.job_worker else "Unknown")
        blockers.append(f"Outstanding worker loan liability: {name} (Remaining balance: ₹{loan.remaining_balance:.2f})")

    # 2. Undispatched Cartons (Stuck in warehouse)
    undispatched = Carton.objects.filter(status="READY")
    for carton in undispatched:
        blockers.append(f"Undispatched Carton in Warehouse: {carton.carton_number} ({carton.total_quantity} pcs)")
        
    return len(blockers) == 0, blockers


def execute_backup_routine(settings_obj=None):
    import os
    import zipfile
    try:
        # Create backups folder inside workspace if it doesn't exist
        backup_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "backups")
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)

        # Collect and serialize model objects
        data_list = []
        data_list.extend(Category.objects.all())
        data_list.extend(Material.objects.all())
        data_list.extend(LegalEntity.objects.all())
        data_list.extend(Warehouse.objects.all())
        data_list.extend(Client.objects.all())
        data_list.extend(Item.objects.all())
        data_list.extend(ItemComposition.objects.all())
        data_list.extend(Worker.objects.all())
        data_list.extend(JobWorker.objects.all())
        data_list.extend(ItemWorkerAllocation.objects.all())
        data_list.extend(Attendance.objects.all())
        data_list.extend(Loan.objects.all())
        data_list.extend(LaborPayment.objects.all())
        data_list.extend(Carton.objects.all())
        data_list.extend(CartonItem.objects.all())
        data_list.extend(StockTransaction.objects.all())

        json_data = serializers.serialize("json", data_list, indent=4)
        
        timestamp = timezone.now().strftime("%Y%m%d_%H%M%S")
        backup_zip_name = f"erp_backup_{timestamp}.zip"
        backup_zip_path = os.path.join(backup_dir, backup_zip_name)

        # Zip JSON data and /media/ directory if exists
        with zipfile.ZipFile(backup_zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr("database_snapshot.json", json_data)

            # Write media files if directory exists
            media_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "media")
            if os.path.exists(media_dir):
                for root, dirs, files in os.walk(media_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, media_dir)
                        zip_file.write(file_path, os.path.join("media", rel_path))

        # Handle auto-rotation retention
        if settings_obj and settings_obj.backup_retention_count:
            retention = settings_obj.backup_retention_count
            all_backups = sorted([f for f in os.listdir(backup_dir) if f.startswith("erp_backup_") and f.endswith(".zip")])
            if len(all_backups) > retention:
                files_to_delete = all_backups[:-retention]
                for file_del in files_to_delete:
                    try:
                        os.remove(os.path.join(backup_dir, file_del))
                    except OSError:
                        pass

        # Log success
        size_kb = os.path.getsize(backup_zip_path) // 1024
        MaintenanceLog.objects.create(
            event_type="backup",
            status="success",
            message=f"Backup completed successfully ({size_kb} KB). File: {backup_zip_name}",
            details=f"Backup saved to: {backup_zip_path}. Retention count applied: {settings_obj.backup_retention_count if settings_obj else 'None'}"
        )
        return True, backup_zip_name, backup_zip_path
    except Exception as e:
        MaintenanceLog.objects.create(
            event_type="backup",
            status="failed",
            message=f"Auto-Backup failed: {str(e)}",
            details=""
        )
        return False, str(e), ""


def execute_delete_routine(settings_obj, force=False):
    try:
        # Determine cut-off date
        freq = settings_obj.auto_delete_frequency
        now = timezone.now()
        if freq == '4_months':
            cut_off_date = now - timezone.timedelta(days=4*30)
        elif freq == '6_months':
            cut_off_date = now - timezone.timedelta(days=6*30)
        elif freq == '1_year':
            cut_off_date = now - timezone.timedelta(days=365)
        else:
            cut_off_date = now - timezone.timedelta(days=6*30)

        # 1. Run Safety Audit
        is_clear, blockers = run_financial_audit(cut_off_date)
        if not is_clear and not force:
            blockers_str = " | ".join(blockers)
            MaintenanceLog.objects.create(
                event_type="audit_fail",
                status="skipped",
                message="Scheduled Auto-Delete skipped: Safety Audit blocked the operation.",
                details=f"Blockers:\n{blockers_str}"
            )
            return False, "skipped", blockers

        # 2. Snapshot first!
        success, backup_name, backup_path = execute_backup_routine(settings_obj)
        if not success:
            raise ValueError(f"Aborting deletion: Pre-purge snapshot failed: {backup_name}")

        # 3. Safe Deletion of old transactions and logs older than cut-off date
        with transaction.atomic():
            tx_count, _ = StockTransaction.objects.filter(created_at__lte=cut_off_date).delete()
            carton_items_count, _ = CartonItem.objects.filter(carton__created_at__lte=cut_off_date).delete()
            cartons_count, _ = Carton.objects.filter(created_at__lte=cut_off_date).delete()
            payments_count, _ = LaborPayment.objects.filter(date__lte=cut_off_date.date()).delete()
            attendance_count, _ = Attendance.objects.filter(date__lte=cut_off_date.date()).delete()

        msg = f"Auto-Delete executed successfully. Purged transactions/logs older than {cut_off_date.strftime('%Y-%m-%d')}. Created safety snapshot: {backup_name}."
        details_str = f"Deleted:\n- {tx_count} stock transactions\n- {cartons_count} cartons\n- {payments_count} payments\n- {attendance_count} attendance records"
        MaintenanceLog.objects.create(
            event_type="delete",
            status="success",
            message=msg,
            details=details_str
        )
        return True, "success", []
    except Exception as e:
        MaintenanceLog.objects.create(
            event_type="delete",
            status="failed",
            message=f"Auto-Delete failed: {str(e)}",
            details=""
        )
        return False, "failed", [str(e)]


def run_automatic_maintenance_checks():
    """
    Evaluates whether scheduled backup or delete tasks are due and runs them.
    Safe against parallel execution locks using simple timestamps comparison.
    """
    settings_obj = MaintenanceSettings.objects.first()
    if not settings_obj:
        return

    now = timezone.now()

    # 1. Evaluate Scheduled Backup
    if settings_obj.auto_backup_enabled:
        due = False
        last = settings_obj.last_backup_run
        if not last:
            due = True
        else:
            freq = settings_obj.auto_backup_frequency
            if freq == 'daily' and now >= last + timezone.timedelta(days=1):
                due = True
            elif freq == 'weekly' and now >= last + timezone.timedelta(days=7):
                due = True
            elif freq == 'monthly' and now >= last + timezone.timedelta(days=30):
                due = True

        if due:
            settings_obj.last_backup_run = now
            settings_obj.save()
            execute_backup_routine(settings_obj)

    # 2. Evaluate Scheduled Auto-Delete
    if settings_obj.auto_delete_enabled:
        due = False
        last = settings_obj.last_delete_run
        if not last:
            due = True
        else:
            freq = settings_obj.auto_delete_frequency
            if freq == '4_months' and now >= last + timezone.timedelta(days=4*30):
                due = True
            elif freq == '6_months' and now >= last + timezone.timedelta(days=6*30):
                due = True
            elif freq == '1_year' and now >= last + timezone.timedelta(days=365):
                due = True

        if due:
            settings_obj.last_delete_run = now
            settings_obj.save()
            execute_delete_routine(settings_obj)


@staff_member_required
def master_bulk_import(request):
    """
    Single unified view that handles rendering the import hub dashboard,
    validating CSV uploads, and committing bulk records in atomic operations (Smart Upsert).
    """
    active_tab = request.GET.get("tab") or request.POST.get("import_type") or "items"
    if active_tab not in ["items", "clients", "workers", "bom", "po", "maintenance"]:
        active_tab = "items"
    preview_rows = []
    has_errors = False
    is_preview = "preview" in request.POST
    is_commit = "commit" in request.POST

    if request.method == "POST" and (is_preview or is_commit):
        csv_file = request.FILES.get("csv_file")
        if not csv_file:
            messages.error(request, "Please select a valid CSV file to upload.")
            return render(request, "import_hub.html", {"active_tab": active_tab})

        try:
            # Parse the uploaded CSV
            file_data = csv_file.read().decode("utf-8-sig")
            io_string = io.StringIO(file_data)
            reader = csv.DictReader(io_string)
            
            # Trim headers to prevent trailing spaces matching errors
            reader.fieldnames = [name.strip() for name in reader.fieldnames] if reader.fieldnames else []
            
            with transaction.atomic():
                for idx, row in enumerate(reader, start=1):
                    # Strip all row cell values
                    row = {k: (v.strip() if v else "") for k, v in row.items()}
                    errors = []
                    action = "NEW"  # Default status for preview
                    if active_tab == "items":
                        code = row.get("Item Code*") or row.get("code")
                        name = row.get("Item Name*") or row.get("name")
                        co_name = (row.get("Company Scope (NC/OM/GLOBAL)*") or row.get("company_name") or "").strip()
                        cl_name = (row.get("Client Scope") or row.get("client_name") or "").strip()
                        row_company = None
                        row_client = None
                        
                        if not code:
                            errors.append("Code is required")
                        else:
                            # Check if item exists for update (Upsert based on unique code)
                            existing_item = Item.objects.filter(code=code).first()
                            if existing_item:
                                action = "UPDATE"
                                
                        if not name:
                            errors.append("Name is required")
                            
                        # Scoping company
                        if co_name and co_name.upper() != "GLOBAL":
                            row_company = LegalEntity.objects.filter(name__iexact=co_name).first()
                            if not row_company:
                                errors.append(f"Company '{co_name}' does not exist in the database")
                                
                        # Scoping Client
                        if cl_name:
                            if row_company:
                                row_client = Client.objects.filter(name__iexact=cl_name, company=row_company).first()
                                if not row_client:
                                    errors.append(f"Client '{cl_name}' not found under company '{row_company.name}'")
                            else:
                                row_client = Client.objects.filter(name__iexact=cl_name).first()
                                if not row_client:
                                    errors.append(f"Client '{cl_name}' not found in database")
                                    
                        # Category validation
                        category = (row.get("Category (BRASS/MORTAR/PESTLE/CHOPPING_BOARD/OTHER)*") or row.get("category") or "OTHER").upper()
                        if category not in [c[0] for c in Item.CATEGORY_CHOICES]:
                            category = "OTHER"
                            
                        # Parse multi-worker piecework allocations
                        worker_rates_str = row.get("Worker Piece-Rates (WorkerName:Rate; WorkerName:Rate)") or row.get("worker_rates") or ""
                        allocations_to_create = []
                        if worker_rates_str:
                            allocs = [a.strip() for a in worker_rates_str.split(";") if a.strip()]
                            for alloc in allocs:
                                if ":" not in alloc:
                                    errors.append(f"Invalid rates mapping format '{alloc}' (must be Name:Rate)")
                                    continue
                                w_name, rate_str = alloc.split(":", 1)
                                w_name = w_name.strip()
                                rate = to_float(rate_str.strip())
                                
                                if row_company:
                                    w_obj = Worker.objects.filter(name=w_name, company=row_company).first()
                                    jw_obj = JobWorker.objects.filter(name=w_name, company=row_company).first() if not w_obj else None
                                  
                                else:
                                    w_obj = Worker.objects.filter(name=w_name).first()
                                    jw_obj = JobWorker.objects.filter(name=w_name).first() if not w_obj else None
                                
                                if not w_obj and not jw_obj:
                                    if row_company:
                                        errors.append(f"Employee/Job Worker '{w_name}' not found under company '{row_company.name}'")
                                    else:
                                        errors.append(f"Employee/Job Worker '{w_name}' not found globally")
                                else:
                                    allocations_to_create.append((w_obj, jw_obj, rate))
 
                        preview_rows.append({
                            "row_num": idx,
                            "data": {
                                "code": code,
                                "name": name,
                                "company_name": co_name,
                                "client_name": cl_name,
                                "category": category,
                                "worker_rates": worker_rates_str
                            },
                            "errors": errors,
                            "is_valid": len(errors) == 0,
                            "action": action
                        })
                        
                        if len(errors) > 0:
                            has_errors = True
                            
                        if is_commit and len(errors) == 0:
                            item_data = {
                                "name": name,
                                "category": category,
                                "sub_category": row.get("Sub Category") or row.get("sub_category", ""),
                                "material": row.get("Material") or row.get("material", "OTHER"),
                                "variant": row.get("Variant") or row.get("variant", ""),
                                "casting_weight": to_float(row.get("Casting Weight (kg)") or row.get("casting_weight", "0")),
                                "machining_weight": to_float(row.get("Machining Weight (kg)") or row.get("machining_weight", "0")),
                                "casting_required": to_bool(row.get("Casting Required (YES/NO)") or row.get("casting_required", "True")),
                                "machining_required": to_bool(row.get("Machining Required (YES/NO)") or row.get("machining_required", "False")),
                                "polishing_required": to_bool(row.get("Polishing Required (YES/NO)") or row.get("polishing_required", "False")),
                                "packing_required": to_bool(row.get("Packing Required (YES/NO)") or row.get("packing_required", "False")),
                                "lot_size": to_int(row.get("Lot Size (pcs)") or row.get("lot_size", "1")),
                                "lot_with_box": to_int(row.get("Lot Weight With Box (kg)") or row.get("lot_with_box", "1")),
                                "rate_per_piece": to_float(row.get("Standard Rate per Piece (₹)") or row.get("rate_per_piece", "0.0")),
                                "company": row_company,
                                "client": row_client
                            }
                            
                            if action == "UPDATE":
                                existing_item = Item.objects.filter(code=code).first()
                                for key, val in item_data.items():
                                    setattr(existing_item, key, val)
                                existing_item.save()
                                item = existing_item
                                # Re-create worker allocations on update
                                ItemWorkerAllocation.objects.filter(item=item).delete()
                            else:
                                item = Item.objects.create(code=code, **item_data)
                                
                            for w_obj, jw_obj, rate in allocations_to_create:
                                ItemWorkerAllocation.objects.create(
                                    item=item,
                                    worker=w_obj,
                                    job_worker=jw_obj,
                                    rate_per_piece=rate
                                )

                    elif active_tab == "clients":
                        name = row.get("Client Name*") or row.get("name")
                        co_name = (row.get("Company Scope (NC/OM)*") or row.get("company_name") or "").strip()
                        cl_code = (row.get("Client Code (Leave blank for auto-generate)") or row.get("client_code") or "").strip()
                        row_company = None
                        
                        if not name:
                            errors.append("Client name is required")
                            
                        if not co_name:
                            errors.append("Company name is required")
                        else:
                            row_company = LegalEntity.objects.filter(name__iexact=co_name).first()
                            if not row_company:
                                errors.append(f"Company '{co_name}' does not exist in the database")
                                
                        if cl_code:
                            existing_client = Client.objects.filter(client_code=cl_code).first()
                            if existing_client:
                                action = "UPDATE"
                        
                        preview_rows.append({
                            "row_num": idx,
                            "data": {
                                "client_code": cl_code,
                                "name": name,
                                "company_name": co_name,
                                "gst_number": row.get("GSTIN Number") or row.get("gst_number", ""),
                                "phone": row.get("Phone") or row.get("phone", ""),
                                "city": row.get("City") or row.get("city", "")
                            },
                            "errors": errors,
                            "is_valid": len(errors) == 0,
                            "action": action
                        })
                        
                        if len(errors) > 0:
                            has_errors = True
                            
                        if is_commit and len(errors) == 0:
                            client_data = {
                                "name": name,
                                "gst_number": row.get("GSTIN Number") or row.get("gst_number", ""),
                                "phone": row.get("Phone") or row.get("phone", ""),
                                "email": row.get("Email") or row.get("email", ""),
                                "city": row.get("City") or row.get("city", ""),
                                "address": row.get("Billing Address") or row.get("address", ""),
                                "company": row_company
                            }
                            if action == "UPDATE":
                                existing_client = Client.objects.filter(client_code=cl_code).first()
                                for key, val in client_data.items():
                                    setattr(existing_client, key, val)
                                existing_client.save()
                            else:
                                # New client creation
                                if cl_code:
                                    Client.objects.create(client_code=cl_code, **client_data)
                                else:
                                    Client.objects.create(**client_data)

                    elif active_tab == "workers":
                        name = row.get("Name*") or row.get("name")
                        co_name = (row.get("Company Scope (NC/OM)*") or row.get("company_name") or "").strip()
                        w_type = (row.get("Worker Type (EMPLOYEE/JOB_WORKER)*") or row.get("worker_type") or "EMPLOYEE").upper()
                        process_str = (row.get("Department Process (casting/machining/polishing/packaging)*") or row.get("process_type") or "machining").lower()
                        w_code = (row.get("Worker Code (Leave blank for auto-generate)") or row.get("worker_code") or "").strip()
                        row_company = None
                        
                        if not name:
                            errors.append("Name is required")
                            
                        if not co_name:
                            errors.append("Company name is required")
                        else:
                            row_company = LegalEntity.objects.filter(name__iexact=co_name).first()
                            if not row_company:
                                errors.append(f"Company '{co_name}' does not exist in the database")
                                
                        if w_type not in ["EMPLOYEE", "JOB_WORKER"]:
                            errors.append("Invalid worker type (must be EMPLOYEE or JOB_WORKER)")
                            
                        if process_str not in [p[0] for p in ProcessType.choices]:
                            errors.append(f"Invalid process department '{process_str}' (must be casting, machining, polishing, or packaging)")
                        if w_code:
                            if w_type == "EMPLOYEE":
                                existing_w = Worker.objects.filter(employee_id=w_code).first()
                                if existing_w:
                                    action = "UPDATE"
                            else:
                                existing_jw = JobWorker.objects.filter(jw_code=w_code).first()
                                if existing_jw:
                                    action = "UPDATE"
                                    
                        # Validate Rates items
                        rates_str = row.get("Rates (ItemCode:Rate,ItemCode:Rate,...)") or row.get("rates") or ""
                        parsed_rates = {}
                        if rates_str:
                            parsed_rates = parse_rates_string(rates_str)
                            for item_code in parsed_rates.keys():
                                if not Item.objects.filter(code__iexact=item_code).exists():
                                    errors.append(f"Item Code '{item_code}' specified in Rates does not exist in the database")
 
                        preview_rows.append({
                            "row_num": idx,
                            "data": {
                                "worker_code": w_code,
                                "name": name,
                                "company_name": co_name,
                                "worker_type": w_type,
                                "process_type": process_str,
                                "daily_rate": row.get("Daily Wage Rate (₹ - Daily Employees)") or row.get("daily_rate", "0")
                            },
                            "errors": errors,
                            "is_valid": len(errors) == 0,
                            "action": action
                        })
                        
                        if len(errors) > 0:
                            has_errors = True
                            
                        if is_commit and len(errors) == 0:
                            if w_type == "EMPLOYEE":
                                sal_model = (row.get("Salary Type (DAILY/FIXED - Employees only)") or row.get("salary_model") or "DAILY").upper()
                                if sal_model not in [s[0] for s in SalaryModel.choices]:
                                    sal_model = SalaryModel.DAILY
                                    
                                emp_data = {
                                    "name": name,
                                    "phone": row.get("Phone") or row.get("phone", ""),
                                    "process": process_str,
                                    "daily_rate": to_float(row.get("Daily Wage Rate (₹ - Daily Employees)") or row.get("daily_rate", "0")),
                                    "monthly_fixed_salary": to_float(row.get("Monthly Fixed Salary (₹ - Fixed Employees)") or row.get("monthly_fixed_salary", "0")),
                                    "casting_rate_per_kg": to_float(row.get("Casting Piece-Rate (₹/kg)") or row.get("casting_rate_per_kg", "0")),
                                    "designation": row.get("Designation") or row.get("designation", ""),
                                    "salary_model": sal_model,
                                    "company": row_company
                                }
                                
                                if action == "UPDATE":
                                    existing_w = Worker.objects.filter(employee_id=w_code).first()
                                    for key, val in emp_data.items():
                                        setattr(existing_w, key, val)
                                    existing_w.save()
                                    worker_obj = existing_w
                                else:
                                    if w_code:
                                        worker_obj = Worker.objects.create(employee_id=w_code, **emp_data)
                                    else:
                                        worker_obj = Worker.objects.create(**emp_data)
                                        
                                # Sync allocated item rates
                                if rates_str:
                                    ItemWorkerAllocation.objects.filter(worker=worker_obj).delete()
                                    for item_code, rate_val in parsed_rates.items():
                                        item_obj = Item.objects.filter(code__iexact=item_code).first()
                                        if item_obj:
                                            ItemWorkerAllocation.objects.create(item=item_obj, worker=worker_obj, rate_per_piece=rate_val)
                            else:
                                jw_data = {
                                    "name": name,
                                    "phone": row.get("Phone") or row.get("phone", ""),
                                    "process": process_str,
                                    "casting_rate_per_kg": to_float(row.get("Casting Piece-Rate (₹/kg)") or row.get("casting_rate_per_kg", "0")),
                                    "address": row.get("Vendor Address (Job Workers)") or row.get("address", ""),
                                    "email": row.get("Vendor Email (Job Workers)") or row.get("email", ""),
                                    "gst_number": row.get("Vendor GSTIN (Job Workers)") or row.get("gst_number", ""),
                                    "company": row_company
                                }
                                if action == "UPDATE":
                                    existing_jw = JobWorker.objects.filter(jw_code=w_code).first()
                                    for key, val in jw_data.items():
                                        setattr(existing_jw, key, val)
                                    existing_jw.save()
                                    jw_obj = existing_jw
                                else:
                                    if w_code:
                                        jw_obj = JobWorker.objects.create(jw_code=w_code, **jw_data)
                                    else:
                                        jw_obj = JobWorker.objects.create(**jw_data)
                                        
                                # Sync allocated item rates
                                if rates_str:
                                    ItemWorkerAllocation.objects.filter(job_worker=jw_obj).delete()
                                    for item_code, rate_val in parsed_rates.items():
                                        item_obj = Item.objects.filter(code__iexact=item_code).first()
                                        if item_obj:
                                            ItemWorkerAllocation.objects.create(item=item_obj, job_worker=jw_obj, rate_per_piece=rate_val)

                    elif active_tab == "bom":
                        parent_code = (row.get("Parent Item Code*") or row.get("parent_item_code") or "").strip()
                        comp_code = (row.get("Component Item Code*") or row.get("component_item_code") or "").strip()
                        qty_str = (row.get("Quantity*") or row.get("quantity") or "").strip()
                        
                        parent_obj = None
                        comp_obj = None
                        
                        if not parent_code:
                            errors.append("Parent item code is required")
                        else:
                            parent_obj = Item.objects.filter(code=parent_code).first()
                            if not parent_obj:
                                errors.append(f"Parent Item with code '{parent_code}' not found")
                                
                        if not comp_code:
                            errors.append("Component item code is required")
                        else:
                            comp_obj = Item.objects.filter(code=comp_code).first()
                            if not comp_obj:
                                errors.append(f"Component Item with code '{comp_code}' not found")
                                
                        qty = to_int(qty_str, 0)
                        if qty <= 0:
                            errors.append("Quantity must be a positive integer greater than 0")
                            
                        # Upsert checks
                        if parent_obj and comp_obj:
                            existing_relation = ItemComposition.objects.filter(parent_item=parent_obj, component_item=comp_obj).first()
                            if existing_relation:
                                action = "UPDATE"
                                
                        preview_rows.append({
                            "row_num": idx,
                            "data": {
                                "parent_item_code": parent_code,
                                "component_item_code": comp_code,
                                "quantity": qty_str
                            },
                            "errors": errors,
                            "is_valid": len(errors) == 0,
                            "action": action
                        })
                        
                        if len(errors) > 0:
                            has_errors = True
                            
                        if is_commit and len(errors) == 0:
                            if action == "UPDATE":
                                existing_relation = ItemComposition.objects.filter(parent_item=parent_obj, component_item=comp_obj).first()
                                existing_relation.quantity = qty
                                existing_relation.save()
                            else:
                                ItemComposition.objects.create(
                                    parent_item=parent_obj,
                                    component_item=comp_obj,
                                    quantity=qty
                                )

                    elif active_tab == "po":
                        po_num = (row.get("PO Number*") or row.get("po_number") or row.get("external_po_number") or "").strip()
                        client_val = (row.get("Client Name or Code*") or row.get("client_name_or_code") or row.get("client") or "").strip()
                        order_date_str = (row.get("Order Date (YYYY-MM-DD)*") or row.get("order_date") or "").strip()
                        promised_date_str = (row.get("Promised Date (YYYY-MM-DD)*") or row.get("promised_date") or "").strip()
                        priority_str = (row.get("Priority (URGENT/NORMAL)*") or row.get("priority") or "NORMAL").strip().upper()
                        item_code = (row.get("Item Code*") or row.get("item_code") or row.get("item") or "").strip()
                        qty_str = (row.get("Ordered Qty*") or row.get("ordered_quantity") or row.get("qty") or "").strip()
                        rate_str = (row.get("Rate per Piece (₹)*") or row.get("rate_per_piece") or row.get("rate") or "").strip()
                        remarks = (row.get("Remarks") or row.get("remarks") or "").strip()
                        
                        client_obj = None
                        item_obj = None
                        order_date = timezone.now().date()
                        promised_date = None
                        
                        if not po_num:
                            errors.append("PO Number is required")
                            
                        if not client_val:
                            errors.append("Client Name or Code is required")
                        else:
                            client_obj = Client.objects.filter(client_code=client_val).first()
                            if not client_obj:
                                client_obj = Client.objects.filter(name__iexact=client_val).first()
                            if not client_obj:
                                errors.append(f"Client '{client_val}' not found")
                                
                        if order_date_str:
                            try:
                                from datetime import datetime
                                order_date = datetime.strptime(order_date_str, "%Y-%m-%d").date()
                            except ValueError:
                                errors.append("Order Date must be in YYYY-MM-DD format")
                                
                        if not promised_date_str:
                            errors.append("Promised Date is required")
                        else:
                            try:
                                from datetime import datetime
                                promised_date = datetime.strptime(promised_date_str, "%Y-%m-%d").date()
                            except ValueError:
                                errors.append("Promised Date must be in YYYY-MM-DD format")
                                
                        if priority_str not in ["NORMAL", "URGENT"]:
                            errors.append("Priority must be either NORMAL or URGENT")
                            
                        if not item_code:
                            errors.append("Item Code is required")
                        else:
                            item_obj = Item.objects.filter(code=item_code).first()
                            if not item_obj:
                                errors.append(f"Item Code '{item_code}' not found")
                                
                        qty = to_int(qty_str, 0)
                        if qty <= 0:
                            errors.append("Ordered Quantity must be a positive integer greater than 0")
                            
                        rate = to_float(rate_str, 0.0)
                        if rate < 0.0:
                            errors.append("Rate per piece cannot be negative")
                            
                        if po_num and client_obj:
                            existing_po = SalesOrder.objects.filter(external_po_number=po_num, client=client_obj).first()
                            if existing_po:
                                action = "UPDATE"
                                
                        preview_rows.append({
                            "row_num": idx,
                            "data": {
                                "po_number": po_num,
                                "client": client_val,
                                "order_date": order_date_str,
                                "promised_date": promised_date_str,
                                "priority": priority_str,
                                "item_code": item_code,
                                "quantity": qty_str,
                                "rate": rate_str,
                                "remarks": remarks
                            },
                            "errors": errors,
                            "is_valid": len(errors) == 0,
                            "action": action
                        })
                        
                        if len(errors) > 0:
                            has_errors = True
                            
                        if is_commit and len(errors) == 0:
                            sales_order_obj, created = SalesOrder.objects.get_or_create(
                                external_po_number=po_num,
                                client=client_obj,
                                defaults={
                                    "order_date": order_date,
                                    "promised_date": promised_date,
                                    "priority": priority_str,
                                    "notes": f"Bulk Imported PO"
                                }
                            )
                            if not created:
                                sales_order_obj.promised_date = promised_date
                                sales_order_obj.priority = priority_str
                                sales_order_obj.save()
                                
                            so_item, item_created = SalesOrderItem.objects.get_or_create(
                                sales_order=sales_order_obj,
                                item=item_obj,
                                defaults={
                                    "ordered_quantity": qty,
                                    "rate_per_piece": rate,
                                    "remarks": remarks
                                }
                            )
                            if not item_created:
                                so_item.ordered_quantity = qty
                                so_item.rate_per_piece = rate
                                so_item.remarks = remarks
                                so_item.save()

                if is_commit and has_errors:
                    # Explicitly trigger database rollback on errors
                    raise ValueError("Import files contains structural validation errors.")

            if is_commit:
                messages.success(request, f"Successfully processed all record imports and updates!")
                return redirect("master_data")
            else:
                messages.info(request, f"CSV parsed successfully. Please inspect the {len(preview_rows)} preview rows before committing.")

        except Exception as e:
            messages.error(request, f"Failed to parse CSV file: {str(e)}")
            preview_rows = []

    return render(request, "import_hub.html", {
        "active_tab": active_tab,
        "preview_rows": preview_rows,
        "has_errors": has_errors,
    })


@staff_member_required
def export_database_backup(request):
    """
    Serializes and exports all master data and transactional records into a single JSON file.
    """
    try:
        # Collect models in topological dependency order (creating parent tables before children)
        data_list = []
        data_list.extend(Category.objects.all())
        data_list.extend(Material.objects.all())
        data_list.extend(LegalEntity.objects.all())
        data_list.extend(Warehouse.objects.all())
        data_list.extend(Client.objects.all())
        data_list.extend(Item.objects.all())
        data_list.extend(ItemComposition.objects.all())
        data_list.extend(Worker.objects.all())
        data_list.extend(JobWorker.objects.all())
        data_list.extend(ItemWorkerAllocation.objects.all())
        data_list.extend(Attendance.objects.all())
        data_list.extend(Loan.objects.all())
        data_list.extend(LaborPayment.objects.all())
        data_list.extend(Carton.objects.all())
        data_list.extend(CartonItem.objects.all())
        data_list.extend(StockTransaction.objects.all())

        # Serialize to JSON format
        json_data = serializers.serialize("json", data_list, indent=4)
        
        timestamp = timezone.now().strftime("%Y%m%d_%H%M%S")
        response = HttpResponse(json_data, content_type="application/json")
        response["Content-Disposition"] = f'attachment; filename="erp_backup_{timestamp}.json"'
        return response
    except Exception as e:
        messages.error(request, f"Failed to export database backup: {str(e)}")
        return redirect(f"{reverse('master_data')}?tab=maintenance")


@staff_member_required
def import_database_backup(request):
    """
    Restores database from an uploaded JSON backup file.
    Uses atomic transaction to ensure absolute rollback on failure.
    """
    if request.method != "POST":
        return redirect(f"{reverse('master_data')}?tab=maintenance")

    backup_file = request.FILES.get("backup_file")
    if not backup_file:
        messages.error(request, "Please choose a valid JSON backup file.")
        return redirect(f"{reverse('master_data')}?tab=maintenance")

    try:
        json_data = backup_file.read().decode("utf-8")
        
        # Parse & deserialize data to test it before clearing the database
        deserialized_objects = list(serializers.deserialize("json", json_data))
        if not deserialized_objects:
            raise ValueError("The backup file is empty or invalid.")

        with transaction.atomic():
            # Clear database tables in reverse dependency order
            StockTransaction.objects.all().delete()
            CartonItem.objects.all().delete()
            Carton.objects.all().delete()
            LaborPayment.objects.all().delete()
            Loan.objects.all().delete()
            Attendance.objects.all().delete()
            ItemWorkerAllocation.objects.all().delete()
            JobWorker.objects.all().delete()
            Worker.objects.all().delete()
            ItemComposition.objects.all().delete()
            Item.objects.all().delete()
            Client.objects.all().delete()
            Warehouse.objects.all().delete()
            LegalEntity.objects.all().delete()
            Material.objects.all().delete()
            Category.objects.all().delete()

            # Save the new deserialized objects
            for obj in deserialized_objects:
                obj.save()

        messages.success(request, f"Database restored successfully! {len(deserialized_objects)} records imported.")
    except Exception as e:
        messages.error(request, f"Failed to restore database: {str(e)}")

    return redirect(f"{reverse('master_data')}?tab=maintenance")


@staff_member_required
def factory_reset_database(request):
    """
    Deletes all transactional, master, and structural data (preserving User profiles/superusers).
    """
    if request.method != "POST":
        return redirect(f"{reverse('master_data')}?tab=maintenance")

    try:
        with transaction.atomic():
            # Delete in strict child-first dependency order
            StockTransaction.objects.all().delete()
            CartonItem.objects.all().delete()
            Carton.objects.all().delete()
            LaborPayment.objects.all().delete()
            Loan.objects.all().delete()
            Attendance.objects.all().delete()
            ItemWorkerAllocation.objects.all().delete()
            JobWorker.objects.all().delete()
            Worker.objects.all().delete()
            ItemComposition.objects.all().delete()
            Item.objects.all().delete()
            Client.objects.all().delete()
            Warehouse.objects.all().delete()
            LegalEntity.objects.all().delete()
            Material.objects.all().delete()
            Category.objects.all().delete()

        messages.success(request, "Database factory reset completed successfully! All records have been cleared.")
    except Exception as e:
        messages.error(request, f"Failed to complete factory reset: {str(e)}")

    return redirect(f"{reverse('master_data')}?tab=maintenance")


@staff_member_required
def save_maintenance_settings(request):
    """
    Saves auto-backup and auto-deletion schedules from user input.
    """
    if request.method != "POST":
        return redirect(f"{reverse('master_data')}?tab=maintenance")

    try:
        settings_obj, _ = MaintenanceSettings.objects.get_or_create(id=1)
        
        settings_obj.auto_backup_enabled = (request.POST.get("auto_backup_enabled") == "on")
        settings_obj.auto_backup_frequency = request.POST.get("auto_backup_frequency", "weekly")
        settings_obj.backup_retention_count = int(request.POST.get("backup_retention_count", 10))

        settings_obj.auto_delete_enabled = (request.POST.get("auto_delete_enabled") == "on")
        settings_obj.auto_delete_frequency = request.POST.get("auto_delete_frequency", "6_months")
        
        settings_obj.save()
        messages.success(request, "Auto-Maintenance schedules and retention policies updated successfully!")
    except Exception as e:
        messages.error(request, f"Failed to save settings: {str(e)}")

    return redirect(f"{reverse('master_data')}?tab=maintenance")


@staff_member_required
def dry_run_audit(request):
    """
    Simulates the scheduled auto-delete task, generating safety audit reports.
    """
    try:
        settings_obj, _ = MaintenanceSettings.objects.get_or_create(id=1)
        freq = settings_obj.auto_delete_frequency
        now = timezone.now()

        if freq == '4_months':
            cut_off_date = now - timezone.timedelta(days=4*30)
            freq_label = "4 Months"
        elif freq == '6_months':
            cut_off_date = now - timezone.timedelta(days=6*30)
            freq_label = "6 Months (Half-Year)"
        elif freq == '1_year':
            cut_off_date = now - timezone.timedelta(days=365)
            freq_label = "1 Year"
        else:
            cut_off_date = now - timezone.timedelta(days=6*30)
            freq_label = "6 Months (Half-Year)"

        is_clear, blockers = run_financial_audit(cut_off_date)

        # Count records eligible for purging
        from apps.production.models import StockTransaction, Carton, LaborPayment, Attendance
        tx_count = StockTransaction.objects.filter(created_at__lte=cut_off_date).count()
        cartons_count = Carton.objects.filter(created_at__lte=cut_off_date).count()
        payments_count = LaborPayment.objects.filter(date__lte=cut_off_date.date()).count()
        attendance_count = Attendance.objects.filter(date__lte=cut_off_date.date()).count()

        total_eligible = tx_count + cartons_count + payments_count + attendance_count

        return JsonResponse({
            "success": True,
            "status": "clear" if is_clear else "blocked",
            "frequency_label": freq_label,
            "cut_off_date": cut_off_date.strftime("%B %d, %Y"),
            "blockers": blockers,
            "counts": {
                "transactions": tx_count,
                "cartons": cartons_count,
                "payments": payments_count,
                "attendance": attendance_count,
                "total": total_eligible
            }
        })
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)
