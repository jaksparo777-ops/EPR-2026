import calendar
from datetime import datetime
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Sum
from django.utils import timezone

from apps.master_data.models import LegalEntity, Client, Warehouse, Item, ItemComposition
from apps.authentication.models import Worker, JobWorker, ProcessType, SalaryModel
from apps.production.models import StockTransaction, TransactionType, ItemWorkerAllocation, Attendance, Loan, LaborPayment, Carton, CartonItem


# =====================================================
# LABOR LEDGER / ATTENDANCE MATRIX / PAYROLL
# =====================================================

@staff_member_required
def labor_ledger(request):
    # Context data
    today = timezone.now().date()
    month_start = today.replace(day=1)
    
    # 0. RESOLVE ACTIVE COMPANY/TEAM
    active_team = request.GET.get('team', 'c1')
    company_id = 2 if active_team == 'c1' else 1
    
    # 1. STAFF PAYROLL (INTERNAL)
    internal_workers = Worker.objects.filter(company_id=company_id)
    staff_ledger = []
    for w in internal_workers:
        # Attendance this month
        attendance_records = Attendance.objects.filter(worker=w, date__gte=month_start)
        days_present = attendance_records.filter(status='PRESENT').count()
        half_days = attendance_records.filter(status='HALF_DAY').count()
        days_absent = attendance_records.filter(status='ABSENT').count()
        total_ot = sum(a.overtime_hours for a in attendance_records)
        
        # Wage Calculation based on Model
        earnings = 0
        if w.salary_model == 'DAILY':
            earnings = (days_present * w.daily_rate) + (half_days * 0.5 * w.daily_rate)
        elif w.salary_model == 'FIXED':
            # Simple daily deduction for fixed salary (Fixed / 30)
            daily_deduct = w.monthly_fixed_salary / 30
            earnings = w.monthly_fixed_salary - (days_absent * daily_deduct)
        
        # Add Overtime & Allowance
        earnings += (total_ot * w.overtime_rate)
        earnings += w.monthly_allowance
        
        # Casting weight-based pay
        casting_pay = 0
        total_casting_wt = 0
        if w.casting_rate_per_kg > 0:
            casting_txs = StockTransaction.objects.filter(
                worker=w,
                transaction_type=TransactionType.CASTING_ENTRY,
                created_at__date__gte=month_start
            )
            total_casting_wt = casting_txs.aggregate(total=Sum('weight'))['total'] or 0
            casting_pay = total_casting_wt * w.casting_rate_per_kg
            earnings += casting_pay

        # Payments & Repayments this month
        payments_qs = LaborPayment.objects.filter(worker=w, date__gte=month_start)
        total_paid = sum(p.amount for p in payments_qs.exclude(payment_type__in=['LOAN_REPAYMENT', 'NEW_LOAN']))
        total_repaid = sum(p.amount for p in payments_qs.filter(payment_type='LOAN_REPAYMENT'))
        
        # Loan Status
        active_loan = w.loans.filter(is_active=True).first()
        
        staff_ledger.append({
            'worker': w,
            'days_present': days_present,
            'half_days': half_days,
            'days_absent': days_absent,
            'ot_hours': total_ot,
            'earnings': earnings,
            'total_paid': total_paid,
            'total_repaid': total_repaid,
            'active_loan': active_loan,
            'casting_pay': casting_pay,
            'total_casting_wt': total_casting_wt,
            'balance': earnings - total_paid - total_repaid
        })
 
    # 2. JOB WORK PAYABLES (EXTERNAL)
    job_workers = JobWorker.objects.filter(company_id=company_id)
    jw_ledger = []
    for jw in job_workers:
        # Calculate Total Earned from Received transactions
        transactions = StockTransaction.objects.filter(
            job_worker=jw, 
            transaction_type__in=['machining_in', 'polishing_in', 'packaging_in']
        )
        
        total_earned = 0
        for tx in transactions:
            # Find the rate for this item and this job worker
            alloc = ItemWorkerAllocation.objects.filter(item=tx.item, job_worker=jw).first()
            if alloc:
                total_earned += (tx.quantity * alloc.rate_per_piece)
        
        # Casting weight-based pay
        casting_pay = 0
        total_casting_wt = 0
        if jw.casting_rate_per_kg > 0:
            casting_txs = StockTransaction.objects.filter(
                job_worker=jw,
                transaction_type=TransactionType.CASTING_ENTRY,
                created_at__date__gte=month_start
            )
            total_casting_wt = casting_txs.aggregate(total=Sum('weight'))['total'] or 0
            casting_pay = total_casting_wt * jw.casting_rate_per_kg
            total_earned += casting_pay

        # Payments to this JW
        payments = LaborPayment.objects.filter(job_worker=jw)
        total_paid = payments.exclude(payment_type__in=['LOAN_REPAYMENT', 'NEW_LOAN']).aggregate(Sum('amount'))['amount__sum'] or 0
        total_repaid = payments.filter(payment_type='LOAN_REPAYMENT').aggregate(Sum('amount'))['amount__sum'] or 0
        
        # Loan Status
        active_loan = jw.loans.filter(is_active=True).first()
        
        jw_ledger.append({
            'jw': jw,
            'total_earned': total_earned,
            'total_paid': total_paid,
            'total_repaid': total_repaid,
            'active_loan': active_loan,
            'casting_pay': casting_pay,
            'total_casting_wt': total_casting_wt,
            'balance': total_earned - total_paid - total_repaid
        })
 
    total_staff_earnings = sum(e['earnings'] for e in staff_ledger)
    total_jw_balance = sum(e['balance'] for e in jw_ledger)
 
    # 3. Monthly Attendance Matrix (for the Full Sheet view)
    num_days = calendar.monthrange(today.year, today.month)[1]
    days_range = range(1, num_days + 1)
    month_end = today.replace(day=num_days)
    
    attendance_matrix = []
    for w in internal_workers:
        row = {'worker': w, 'days': []}
        att_records = Attendance.objects.filter(worker=w, date__gte=month_start, date__lte=month_end)
        att_dict = {r.date.day: r for r in att_records}
        
        for d in days_range:
            record = att_dict.get(d)
            date_str = today.replace(day=d).strftime('%Y-%m-%d')
            if record:
                row['days'].append({
                    'day': d,
                    'status': record.status,
                    'ot': record.overtime_hours,
                    'date_str': date_str
                })
            else:
                row['days'].append({
                    'day': d,
                    'status': None,
                    'ot': 0,
                    'date_str': date_str
                })
        attendance_matrix.append(row)
 
    company1 = LegalEntity.objects.filter(id=2).first()
    company2 = LegalEntity.objects.filter(id=1).first()

    context = {
        'staff_ledger': staff_ledger,
        'jw_ledger': jw_ledger,
        'attendance_matrix': attendance_matrix,
        'days_range': days_range,
        'total_staff_earnings': total_staff_earnings,
        'total_jw_balance': total_jw_balance,
        'items': Item.objects.filter(client__company_id=company_id),
        'today': today,
        'month_name': today.strftime('%B %Y'),
        'active_team': active_team,
        'company1': company1,
        'company2': company2,
    }
    return render(request, 'labor_ledger.html', context)

# =====================================================
# WORKER MONTHLY REPORT (PAY SLIP & CALENDAR)
# =====================================================

@staff_member_required
def worker_monthly_report(request, worker_id):
    worker = get_object_or_404(Worker, id=worker_id)
    today = timezone.now().date()
    month_start = today.replace(day=1)
    num_days = calendar.monthrange(today.year, today.month)[1]
    month_end = today.replace(day=num_days)
    
    attendance = Attendance.objects.filter(worker=worker, date__gte=month_start, date__lte=month_end).order_by('date')
    payments = LaborPayment.objects.filter(worker=worker, date__gte=month_start, date__lte=month_end).order_by('date')
    
    # Statistics
    days_present = attendance.filter(status='PRESENT').count()
    half_days = attendance.filter(status='HALF_DAY').count()
    days_absent = attendance.filter(status='ABSENT').count()
    total_ot = sum(a.overtime_hours for a in attendance)
    
    # Earnings Calculation (Consistent with labor_ledger logic)
    attendance_ledger = []
    earned_wages = 0
    
    daily_rate = worker.daily_rate if worker.salary_model == 'DAILY' else (worker.monthly_fixed_salary / 30)
    
    for a in attendance:
        day_earned = 0
        if a.status == 'PRESENT':
            day_earned = daily_rate
        elif a.status == 'HALF_DAY':
            day_earned = daily_rate * 0.5
        
        # Add OT for that day
        day_earned += (a.overtime_hours * worker.overtime_rate)
        earned_wages += day_earned
        
        attendance_ledger.append({
            'date': a.date,
            'status': a.status,
            'ot': a.overtime_hours,
            'rate': daily_rate,
            'earned': day_earned
        })
    
    # Adjust for FIXED salary if needed
    if worker.salary_model == 'FIXED':
        # In fixed model, we start with full salary and subtract absents
        daily_deduct = worker.monthly_fixed_salary / 30
        earned_wages = worker.monthly_fixed_salary - (days_absent * daily_deduct) + (total_ot * worker.overtime_rate)

    # Add Monthly Allowance
    earned_wages += worker.monthly_allowance

    total_paid = sum(p.amount for p in payments)
    
    # Calendar Logic for the printable report
    first_day_of_month = month_start.weekday() # Monday is 0, Sunday is 6
    # Adjust to Sunday as first day (Sunday=0, Monday=1, ...)
    first_day_of_month = (first_day_of_month + 1) % 7
    
    calendar_weeks = []
    current_week = [None] * first_day_of_month
    
    # Map attendance by day
    att_by_day = {a.date.day: a for a in attendance}
    
    for d in range(1, num_days + 1):
        record = att_by_day.get(d)
        current_week.append({
            'day': d,
            'status': record.status if record else None,
            'ot': record.overtime_hours if record else 0
        })
        if len(current_week) == 7:
            calendar_weeks.append(current_week)
            current_week = []
    
    if current_week:
        while len(current_week) < 7:
            current_week.append(None)
        calendar_weeks.append(current_week)

    # Loan context
    active_loan = worker.loans.filter(is_active=True).first()
    loan_repaid_this_month = sum(p.amount for p in payments if p.payment_type == 'LOAN_REPAYMENT')
    total_paid_regular = sum(p.amount for p in payments if p.payment_type not in ['LOAN_REPAYMENT', 'NEW_LOAN'])

    context = {
        'worker': worker,
        'stats': {
            'present': days_present,
            'half': half_days,
            'absent': days_absent,
            'ot': total_ot,
            'earned': earned_wages,
            'loan_repaid': loan_repaid_this_month,
            'loan_balance': active_loan.remaining_balance if active_loan else 0,
            'balance': earned_wages - total_paid_regular - loan_repaid_this_month
        },
        'calendar_weeks': calendar_weeks,
        'attendance_ledger': attendance_ledger,
        'payments': payments,
        'month_name': today.strftime('%B %Y'),
        'today': timezone.now()
    }
    return render(request, 'worker_report.html', context)

# =====================================================
# JOB WORKER MONTHLY REPORT (PIECE-RATE LEDGER)
# =====================================================

@staff_member_required
def job_worker_monthly_report(request, jw_id):
    from datetime import datetime
    
    jw = JobWorker.objects.get(id=jw_id)
    month_str = request.GET.get('month', timezone.now().strftime('%Y-%m'))
    month_dt = datetime.strptime(month_str, '%Y-%m')
    
    # 1. Filter Transactions for the month
    transactions = StockTransaction.objects.filter(
        job_worker=jw, 
        created_at__year=month_dt.year, 
        created_at__month=month_dt.month
    ).order_by('created_at')
    
    # 2. Filter Payments
    payments = LaborPayment.objects.filter(
        job_worker=jw,
        date__year=month_dt.year,
        date__month=month_dt.month
    )
    
    # 3. Aggregate by Item & Calculate Balances
    all_jw_tx = StockTransaction.objects.filter(job_worker=jw).order_by('created_at')
    
    # Track running balances for ALL time to get accurate current BAL
    item_balances = {}
    for tx in all_jw_tx:
        in_qty = tx.quantity if tx.transaction_type.endswith('_out') else 0
        out_qty = tx.quantity if tx.transaction_type.endswith('_in') else 0
        
        if tx.item_id not in item_balances:
            item_balances[tx.item_id] = 0
        item_balances[tx.item_id] += (in_qty - out_qty)

    # Filter for the current month and aggregate by (Item, Date)
    item_ledger = {}
    for tx in all_jw_tx.filter(created_at__year=month_dt.year, created_at__month=month_dt.month):
        date_key = tx.created_at.date()
        key = (tx.item_id, date_key)
        
        if key not in item_ledger:
            item_ledger[key] = {
                'name': tx.item.name,
                'code': tx.item.code,
                'date': date_key,
                'in': 0,
                'out': 0,
                'bal': 0, # Will fill this after
                'earned': 0
            }
        
        if tx.transaction_type.endswith('_out'):
            item_ledger[key]['in'] += tx.quantity
        elif tx.transaction_type.endswith('_in'):
            item_ledger[key]['out'] += tx.quantity
            alloc = ItemWorkerAllocation.objects.filter(job_worker=jw, item=tx.item).first()
            rate = float(alloc.rate_per_piece) if alloc else 0
            item_ledger[key]['earned'] += (tx.quantity * rate)

    # Calculate balances chronologically for the displayed keys
    sorted_keys = sorted(item_ledger.keys(), key=lambda x: x[1])
    
    # We also need the opening balances for each item at the start of the month
    opening_balances = {}
    previous_tx = all_jw_tx.filter(created_at__lt=month_dt)
    for tx in previous_tx:
        in_qty = tx.quantity if tx.transaction_type.endswith('_out') else 0
        out_qty = tx.quantity if tx.transaction_type.endswith('_in') else 0
        opening_balances[tx.item_id] = opening_balances.get(tx.item_id, 0) + (in_qty - out_qty)

    current_item_balances = opening_balances.copy()
    for key in sorted_keys:
        item_id = key[0]
        item_ledger[key]['bal'] = current_item_balances.get(item_id, 0) + item_ledger[key]['in'] - item_ledger[key]['out']
        current_item_balances[item_id] = item_ledger[key]['bal']

    total_earned = sum(item['earned'] for item in item_ledger.values())
    total_paid = sum(p.amount for p in payments)
    
    # Final sorted list for template
    ledger_entries = sorted(item_ledger.values(), key=lambda x: x['date'])

    context = {
        'jw': jw,
        'month_name': month_dt.strftime('%B %Y'),
        'month_val': month_str,
        'item_ledger': ledger_entries,
        'payments': payments,
        'total_earned': total_earned,
        'total_paid': total_paid,
        'balance': total_earned - total_paid,
        'today': timezone.now(),
    }
    return render(request, 'job_worker_report.html', context)
