from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from core.security import require_role
from apps.monitoring.models import UserSession, AuditLog

@require_role('System Admin')
def monitoring_dashboard(request):
    """
    Renders the central security control panel dashboard.
    Restricted to System Admin role operators.
    """
    # Active Session Window: 15 minutes of inactivity threshold
    inactivity_threshold = timezone.now() - timezone.timedelta(minutes=15)
    
    # Active sessions
    active_sessions = UserSession.objects.filter(
        is_active=True,
        last_activity__gte=inactivity_threshold
    ).select_related('user')
    
    # Audit Logs filtering
    query = request.GET.get('q', '').strip()
    dept_filter = request.GET.get('dept', '').strip()
    action_filter = request.GET.get('action', '').strip()
    
    logs = AuditLog.objects.all().select_related('user')
    
    if query:
        logs = logs.filter(
            Q(user__username__icontains=query) |
            Q(details__icontains=query) |
            Q(object_repr__icontains=query)
        )
        
    if dept_filter:
        logs = logs.filter(department=dept_filter)
        
    if action_filter:
        logs = logs.filter(action=action_filter)
        
    # Get last 150 log entries for performance
    logs = logs[:150]
    
    # KPI metrics calculation
    today_start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    active_ops_count = active_sessions.values('user').distinct().count()
    total_active_devices = active_sessions.count()
    
    alerts_today = AuditLog.objects.filter(
        timestamp__gte=today_start,
        action__in=['DELETE', 'TERMINATE']
    ).count()
    
    context = {
        'active_sessions': active_sessions,
        'logs': logs,
        'active_ops_count': active_ops_count,
        'total_active_devices': total_active_devices,
        'alerts_today': alerts_today,
        'query': query,
        'dept_filter': dept_filter,
        'action_filter': action_filter,
        'departments': AuditLog.DEPARTMENT_CHOICES,
        'actions': AuditLog.ACTION_CHOICES,
    }
    
    return render(request, 'monitoring/dashboard.html', context)


@require_role('System Admin')
def terminate_session(request, session_id):
    """
    Forcefully terminates an active user session.
    Revokes the active flag and purges from Django's backend session storage.
    """
    if request.method == 'POST':
        user_session = get_object_or_404(UserSession, id=session_id)
        
        # Don't let admins kill their own active session
        admin_session_key = request.session.session_key
        if user_session.session_key == admin_session_key:
            messages.error(request, "Security Safeguard: You cannot terminate your own active session.")
            return redirect('monitoring_dashboard')
            
        # 1. Mark session inactive in custom DB log
        user_session.is_active = False
        user_session.save()
        
        # 2. Delete the session from Django session backend
        try:
            session_obj = Session.objects.get(session_key=user_session.session_key)
            session_obj.delete()
        except Session.DoesNotExist:
            pass
            
        # 3. Log security alert audit entry
        AuditLog.objects.create(
            user=request.user,
            ip_address=request.META.get('REMOTE_ADDR'),
            department='security',
            action='TERMINATE',
            object_repr=f"Session: {user_session.user.username}",
            details=f"Admin {request.user.username} force terminated active session of {user_session.user.username} (IP: {user_session.ip_address})."
        )
        
        messages.success(request, f"Successfully terminated active session for user: {user_session.user.username}.")
        
    return redirect('monitoring_dashboard')
