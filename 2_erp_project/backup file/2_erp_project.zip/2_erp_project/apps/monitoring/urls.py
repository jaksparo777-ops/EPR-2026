from django.urls import path
from apps.monitoring.views import monitoring_dashboard, terminate_session

urlpatterns = [
    path('monitoring/', monitoring_dashboard, name='monitoring_dashboard'),
    path('monitoring/terminate-session/<int:session_id>/', terminate_session, name='terminate_session'),
]
