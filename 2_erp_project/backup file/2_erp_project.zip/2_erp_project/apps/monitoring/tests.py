from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.urls import reverse
from django.utils import timezone
from apps.monitoring.models import UserSession, AuditLog
from apps.workforce.models import Worker
from apps.products.models import Material

class MonitoringSystemTestCase(TestCase):
    def setUp(self):
        # Create standard test password
        self.password = "Foundry@2026"
        
        # Setup groups
        self.admin_group, _ = Group.objects.get_or_create(name='System Admin')
        self.operator_group, _ = Group.objects.get_or_create(name='Production Operator')
        
        # Create users
        self.admin_user = User.objects.create_user(
            username='admin_operator', 
            email='admin@foundry.com', 
            password=self.password
        )
        self.admin_user.groups.add(self.admin_group)
        
        self.operator_user = User.objects.create_user(
            username='standard_operator', 
            email='operator@foundry.com', 
            password=self.password
        )
        self.operator_user.groups.add(self.operator_group)
        
        # Set up a testing client
        self.client = Client()

    def test_login_creates_session_and_audit(self):
        """Verify that logging in registers a UserSession and logs an login audit entry."""
        # Clean existing sessions/logs to isolate test
        UserSession.objects.all().delete()
        AuditLog.objects.all().delete()
        
        # Authenticate Standard Operator
        login_success = self.client.login(username='standard_operator', password=self.password)
        self.assertTrue(login_success)
        
        # Make a dummy request to trigger session creation in middleware
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        
        # Check active session created
        sessions = UserSession.objects.filter(user=self.operator_user, is_active=True)
        self.assertEqual(sessions.count(), 1)
        session = sessions.first()
        self.assertEqual(session.device_type, 'Desktop') # Default client is desktop user agent
        
        # Check audit log entry
        login_audits = AuditLog.objects.filter(user=self.operator_user, action='LOGIN')
        self.assertEqual(login_audits.count(), 1)
        self.assertIn("successfully authenticated", login_audits.first().details)

    def test_database_operation_auditing(self):
        """Verify that db insertions/modifications automatically generate detailed AuditLog entries."""
        # Log in standard operator
        self.client.login(username='standard_operator', password=self.password)
        
        # Perform request that saves a model to the DB.
        # To avoid UI form dependency, we trigger save inside a mock request block
        # Or let's trigger it directly. The middleware sets the contextvars thread-locals.
        # Let's test that when contextvars are set, saving a model records the user.
        from apps.monitoring.middleware import _user, _ip
        
        user_token = _user.set(self.operator_user)
        ip_token = _ip.set("127.0.0.1")
        
        try:
            # Create a Material
            material = Material.objects.create(name="Graphite Powder")
            
            # Verify AuditLog created
            material_audits = AuditLog.objects.filter(department='products', action='CREATE')
            self.assertEqual(material_audits.count(), 1)
            audit = material_audits.first()
            self.assertEqual(audit.user, self.operator_user)
            self.assertEqual(audit.ip_address, "127.0.0.1")
            self.assertIn("Graphite Powder", audit.object_repr)
            self.assertIn("Graphite Powder", audit.details)
            
            # Update the Material
            material.name = "Graphite Dust"
            material.save()
            
            update_audits = AuditLog.objects.filter(department='products', action='UPDATE')
            self.assertEqual(update_audits.count(), 1)
            self.assertIn("updated", update_audits.first().details)
            
            # Delete the Material
            material.delete()
            delete_audits = AuditLog.objects.filter(department='products', action='DELETE')
            self.assertEqual(delete_audits.count(), 1)
            self.assertIn("deleted", delete_audits.first().details)
            
        finally:
            _user.reset(user_token)
            _ip.reset(ip_token)

    def test_dashboard_access_restrictions(self):
        """Verify that only users with System Admin role can access the monitoring center."""
        # 1. Non-admin operator tries to access
        self.client.login(username='standard_operator', password=self.password)
        response = self.client.get(reverse('monitoring_dashboard'))
        # Should deny access and redirect to dashboard
        self.assertRedirects(response, reverse('dashboard'))
        
        # 2. Admin operator tries to access
        self.client.login(username='admin_operator', password=self.password)
        response = self.client.get(reverse('monitoring_dashboard'))
        self.assertEqual(response.status_code, 200)

    def test_session_termination_force_logout(self):
        """Verify that force-killing a session logs out the user on their next request."""
        # Log in standard operator
        self.client.login(username='standard_operator', password=self.password)
        
        # Visit page to register UserSession
        self.client.get(reverse('dashboard'))
        session_record = UserSession.objects.get(user=self.operator_user, is_active=True)
        
        # Simulate Admin force terminating standard operator session via POST
        self.client.login(username='admin_operator', password=self.password)
        response = self.client.post(reverse('terminate_session', args=[session_record.id]))
        self.assertRedirects(response, reverse('monitoring_dashboard'))
        
        # Verify custom session is inactive
        session_record.refresh_from_db()
        self.assertFalse(session_record.is_active)
        
        # Verify standard operator's client is force logged out on subsequent requests
        # We restore the standard operator's client session keys
        self.client.login(username='standard_operator', password=self.password)
        # Manually force set the terminated session key on client
        session = self.client.session
        session_record.session_key = session.session_key
        session_record.is_active = False
        session_record.save()
        
        # Try to view a page
        response = self.client.get(reverse('dashboard'))
        # Should be forced to redirect to login page!
        self.assertRedirects(response, reverse('login'))
