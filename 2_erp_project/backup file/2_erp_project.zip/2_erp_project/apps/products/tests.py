from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.urls import reverse

class SecurityRBACAndAccessTestCase(TestCase):
    """
    Automated verification of role-based access control (RBAC).
    Verifies that unauthenticated, unauthorized, and authorized users
    are handled correctly by core decorators and middleware.
    """

    def setUp(self):
        self.client = Client()

        # Retrieve or create Groups
        self.admin_group, _ = Group.objects.get_or_create(name='System Admin')
        self.operator_group, _ = Group.objects.get_or_create(name='Production Operator')
        self.logistics_group, _ = Group.objects.get_or_create(name='Logistics Supervisor')
        self.hr_group, _ = Group.objects.get_or_create(name='HR & Accounts Manager')

        # Create test users
        self.admin_user = User.objects.create_user(
            username='admin_test',
            email='admin@test.com',
            password='testpassword'
        )
        self.admin_user.groups.add(self.admin_group)

        self.operator_user = User.objects.create_user(
            username='operator_test',
            email='operator@test.com',
            password='testpassword'
        )
        self.operator_user.groups.add(self.operator_group)

        self.logistics_user = User.objects.create_user(
            username='logistics_test',
            email='logistics@test.com',
            password='testpassword'
        )
        self.logistics_user.groups.add(self.logistics_group)

        self.hr_user = User.objects.create_user(
            username='hr_test',
            email='hr@test.com',
            password='testpassword'
        )
        self.hr_user.groups.add(self.hr_group)

        self.regular_user = User.objects.create_user(
            username='regular_test',
            email='regular@test.com',
            password='testpassword'
        )

        # Standard secure URLs for verification
        self.dashboard_url = reverse('dashboard')
        self.casting_url = reverse('casting_entry')
        self.packaging_url = reverse('packaging')
        self.labor_ledger_url = reverse('labor_ledger')

    def test_unauthenticated_user_redirects_to_login(self):
        """
        Unauthenticated requests to restricted pages must redirect to the login screen.
        """
        urls = [self.dashboard_url, self.casting_url, self.packaging_url, self.labor_ledger_url]
        for url in urls:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 302)
            self.assertIn('/login/', response.url)

    def test_production_operator_access(self):
        """
        Production operators must have access to furnace casting, machining, etc.,
        but be strictly blocked from packaging and payroll.
        """
        self.client.login(username='operator_test', password='testpassword')

        # 1. Allowed sections
        response = self.client.get(self.dashboard_url)
        self.assertEqual(response.status_code, 200)

        response = self.client.get(self.casting_url)
        self.assertEqual(response.status_code, 200)

        # 2. Blocked sections (redirect to dashboard with error)
        response = self.client.get(self.packaging_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.dashboard_url)

        response = self.client.get(self.labor_ledger_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.dashboard_url)

    def test_logistics_supervisor_access(self):
        """
        Logistics supervisors must have access to dispatch and packaging dashboards,
        but be strictly blocked from casting logs and payroll ledger.
        """
        self.client.login(username='logistics_test', password='testpassword')

        # 1. Allowed sections
        response = self.client.get(self.dashboard_url)
        self.assertEqual(response.status_code, 200)

        response = self.client.get(self.packaging_url)
        self.assertEqual(response.status_code, 200)

        # 2. Blocked sections
        response = self.client.get(self.casting_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.dashboard_url)

        response = self.client.get(self.labor_ledger_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.dashboard_url)

    def test_hr_accounts_manager_access(self):
        """
        HR/Accounts managers must have access to worker records and salary ledgers,
        but be blocked from casting logs and packaging queues.
        """
        self.client.login(username='hr_test', password='testpassword')

        # 1. Allowed sections
        response = self.client.get(self.dashboard_url)
        self.assertEqual(response.status_code, 200)

        response = self.client.get(self.labor_ledger_url)
        self.assertEqual(response.status_code, 200)

        # 2. Blocked sections
        response = self.client.get(self.casting_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.dashboard_url)

        response = self.client.get(self.packaging_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, self.dashboard_url)

    def test_system_admin_bypass_and_global_access(self):
        """
        System admin user (or superuser/staff) must have unrestricted global access.
        """
        self.client.login(username='admin_test', password='testpassword')

        urls = [self.dashboard_url, self.casting_url, self.packaging_url, self.labor_ledger_url]
        for url in urls:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 200)

    def test_unauthorized_regular_user_blocked_from_all(self):
        """
        A standard authenticated user with no specific role/groups must be blocked
        from all operational screens except the dashboard.
        """
        self.client.login(username='regular_test', password='testpassword')

        # 1. Allowed sections
        response = self.client.get(self.dashboard_url)
        self.assertEqual(response.status_code, 200)

        # 2. Blocked sections
        restricted_urls = [self.casting_url, self.packaging_url, self.labor_ledger_url]
        for url in restricted_urls:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 302)
            self.assertEqual(response.url, self.dashboard_url)
