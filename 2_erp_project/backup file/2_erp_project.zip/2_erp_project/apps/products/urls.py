from django.urls import path
from django.contrib.auth import views as auth_views
from apps.products.views import (
    dashboard,
    master_data,
    delete_item,
    delete_items_bulk,
    delete_client,
    edit_item,
    get_item_composition,
)

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('', dashboard, name='dashboard'),
    path('master-data/', master_data, name='master_data'),
    path('delete-item/<int:item_id>/', delete_item, name='delete_item'),
    path('delete-items-bulk/', delete_items_bulk, name='delete_items_bulk'),
    path('delete-client/<int:client_id>/', delete_client, name='delete_client'),
    path('edit-item/<int:item_id>/', edit_item, name='edit_item'),
    path('api/item/<int:item_id>/composition/', get_item_composition, name='get_item_composition'),
]
