from django import forms
from .models import Item, Client, Category, Material

class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = [
            'code', 'name', 'client', 'category', 'sub_category', 'material', 'variant', 'item_type',
            'casting_weight', 'machining_weight',
            'lot_size', 'lot_with_box',
            'casting_required', 'machining_required', 'polishing_required', 'packing_required', 'notes'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        cats = Category.objects.all().order_by('name')
        self.fields['category'] = forms.ChoiceField(
            choices=[(c.name, c.name) for c in cats],
            widget=forms.Select(attrs={'class': 'form-control'})
        )
        
        mats = Material.objects.all().order_by('name')
        self.fields['material'] = forms.ChoiceField(
            choices=[(m.name, m.name) for m in mats],
            widget=forms.Select(attrs={'class': 'form-control'})
        )


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['name', 'phone', 'email', 'city', 'address', 'gst_number']
