# Core package module
