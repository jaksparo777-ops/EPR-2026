# templatetags package initialization
